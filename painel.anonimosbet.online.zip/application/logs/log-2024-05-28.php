<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-05-28 13:35:10 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:35:13 --> Total execution time: 2.5949
DEBUG - 2024-05-28 13:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:35:17 --> Total execution time: 1.4589
DEBUG - 2024-05-28 13:36:32 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:36:34 --> Total execution time: 2.1185
DEBUG - 2024-05-28 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:38:39 --> Total execution time: 2.4505
DEBUG - 2024-05-28 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:39:39 --> Total execution time: 2.1795
DEBUG - 2024-05-28 13:43:16 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:43:18 --> Total execution time: 2.1890
DEBUG - 2024-05-28 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:43:39 --> Total execution time: 2.4096
DEBUG - 2024-05-28 13:43:41 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:43:42 --> Total execution time: 1.4086
DEBUG - 2024-05-28 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:45:58 --> Total execution time: 1.6536
DEBUG - 2024-05-28 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:46:01 --> Total execution time: 1.4933
DEBUG - 2024-05-28 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 13:48:22 --> 404 Page Not Found: P/index
DEBUG - 2024-05-28 13:48:23 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 13:48:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-05-28 13:48:25 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:25 --> No URI present. Default controller set.
DEBUG - 2024-05-28 13:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:48:26 --> Total execution time: 1.2065
DEBUG - 2024-05-28 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:48:38 --> Total execution time: 1.7320
DEBUG - 2024-05-28 13:48:39 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 13:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 13:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 13:48:41 --> Total execution time: 1.4273
DEBUG - 2024-05-28 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 14:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 14:05:40 --> Total execution time: 1.4269
DEBUG - 2024-05-28 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 14:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 14:17:47 --> Total execution time: 2.2757
DEBUG - 2024-05-28 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 14:29:33 --> No URI present. Default controller set.
DEBUG - 2024-05-28 14:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 14:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-05-28 14:29:35 --> Total execution time: 1.1647
DEBUG - 2024-05-28 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 17:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 17:05:48 --> 404 Page Not Found: Site/templates
ERROR - 2024-05-28 17:05:48 --> 404 Page Not Found: Site/templates
DEBUG - 2024-05-28 17:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 17:05:49 --> 404 Page Not Found: Crashou3mp3/index
DEBUG - 2024-05-28 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-05-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 17:06:34 --> 404 Page Not Found: Site/js
ERROR - 2024-05-28 17:06:34 --> 404 Page Not Found: Site/js
ERROR - 2024-05-28 17:06:34 --> 404 Page Not Found: Site/js
ERROR - 2024-05-28 17:06:34 --> 404 Page Not Found: Site/js
DEBUG - 2024-05-28 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2024-05-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-05-28 17:06:34 --> 404 Page Not Found: Site/js
