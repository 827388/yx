<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-07 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:16:20 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:16:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /www/wwwroot/painel.fire777.online/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-07 14:16:20 --> Unable to connect to the database
DEBUG - 2024-07-07 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:16:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:16:21 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:16:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /www/wwwroot/painel.fire777.online/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-07 14:16:21 --> Unable to connect to the database
DEBUG - 2024-07-07 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:17:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:05 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:05 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:05 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:05 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:05 --> Total execution time: 0.0445
DEBUG - 2024-07-07 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:07 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:07 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:07 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:07 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:07 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:07 --> Total execution time: 0.0657
DEBUG - 2024-07-07 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:07 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:07 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:07 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:07 --> Total execution time: 0.1486
DEBUG - 2024-07-07 14:18:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:18:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 14:18:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:18:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 14:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:10 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:10 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:10 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:11 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:11 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:11 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:11 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:11 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:11 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:11 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:11 --> Total execution time: 0.1115
DEBUG - 2024-07-07 14:18:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:53 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:53 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:53 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:54 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:54 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:54 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:18:54 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:18:55 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:18:55 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:18:55 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:18:55 --> Total execution time: 0.1074
DEBUG - 2024-07-07 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:19:16 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:19:16 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:19:16 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:19:16 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:19:16 --> Total execution time: 0.1279
DEBUG - 2024-07-07 14:19:23 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:19:23 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:19:23 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:19:23 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:19:24 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:19:24 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:19:24 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:19:24 --> Total execution time: 0.0891
DEBUG - 2024-07-07 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-07-07 14:19:27 --> Severity: Warning --> mkdir(): Invalid path /www/wwwroot/painel.fire777.online/system/libraries/Session/drivers/Session_files_driver.php 137
ERROR - 2024-07-07 14:19:27 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2024-07-07 14:19:27 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /www/wwwroot/painel.fire777.online/system/libraries/Session/Session.php 137
DEBUG - 2024-07-07 14:19:27 --> Total execution time: 0.0364
DEBUG - 2024-07-07 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:21:29 --> Total execution time: 0.0964
DEBUG - 2024-07-07 14:21:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:21:34 --> Total execution time: 0.3141
DEBUG - 2024-07-07 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:21:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:21:49 --> Total execution time: 0.2075
DEBUG - 2024-07-07 14:22:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:22:18 --> Total execution time: 0.2170
DEBUG - 2024-07-07 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:24:17 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:24:17 --> Total execution time: 0.0896
DEBUG - 2024-07-07 14:27:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:27:09 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:27:09 --> Total execution time: 0.0342
DEBUG - 2024-07-07 14:28:27 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 14:28:27 --> 404 Page Not Found: Https:/painel.fire777.online
DEBUG - 2024-07-07 14:46:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:46:50 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:46:51 --> Total execution time: 0.5784
DEBUG - 2024-07-07 14:47:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:47:17 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:47:17 --> Total execution time: 0.0781
DEBUG - 2024-07-07 14:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 14:47:49 --> No URI present. Default controller set.
DEBUG - 2024-07-07 14:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 14:47:49 --> Total execution time: 0.0484
DEBUG - 2024-07-07 15:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:46 --> Total execution time: 0.0404
DEBUG - 2024-07-07 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:53 --> Total execution time: 0.0689
DEBUG - 2024-07-07 15:01:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:58 --> Total execution time: 0.1351
DEBUG - 2024-07-07 15:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:01:59 --> Total execution time: 0.0538
DEBUG - 2024-07-07 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:03:10 --> Total execution time: 0.0836
DEBUG - 2024-07-07 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:15:40 --> No URI present. Default controller set.
DEBUG - 2024-07-07 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:15:40 --> Total execution time: 0.0491
DEBUG - 2024-07-07 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:15:42 --> No URI present. Default controller set.
DEBUG - 2024-07-07 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:15:42 --> Total execution time: 0.0996
DEBUG - 2024-07-07 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 15:15:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 15:15:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:15:44 --> No URI present. Default controller set.
DEBUG - 2024-07-07 15:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:15:44 --> Total execution time: 0.1516
DEBUG - 2024-07-07 15:15:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:15:44 --> No URI present. Default controller set.
DEBUG - 2024-07-07 15:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:15:45 --> Total execution time: 0.2263
DEBUG - 2024-07-07 15:51:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 15:51:45 --> No URI present. Default controller set.
DEBUG - 2024-07-07 15:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 15:51:45 --> Total execution time: 0.2442
DEBUG - 2024-07-07 16:50:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 16:50:17 --> No URI present. Default controller set.
DEBUG - 2024-07-07 16:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 16:50:18 --> Total execution time: 0.2666
DEBUG - 2024-07-07 17:14:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 17:14:47 --> No URI present. Default controller set.
DEBUG - 2024-07-07 17:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 17:14:47 --> Total execution time: 0.1299
DEBUG - 2024-07-07 17:52:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 17:52:40 --> No URI present. Default controller set.
DEBUG - 2024-07-07 17:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 17:52:40 --> Total execution time: 0.1674
DEBUG - 2024-07-07 20:18:14 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 20:18:14 --> No URI present. Default controller set.
DEBUG - 2024-07-07 20:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 20:18:14 --> Total execution time: 0.1348
DEBUG - 2024-07-07 22:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:23:29 --> No URI present. Default controller set.
DEBUG - 2024-07-07 22:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 22:23:29 --> Total execution time: 0.1742
DEBUG - 2024-07-07 22:23:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 22:23:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-07 22:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:29:48 --> No URI present. Default controller set.
DEBUG - 2024-07-07 22:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 22:29:48 --> Total execution time: 0.1769
DEBUG - 2024-07-07 22:29:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:29:49 --> No URI present. Default controller set.
DEBUG - 2024-07-07 22:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 22:29:49 --> Total execution time: 0.0462
DEBUG - 2024-07-07 22:29:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:29:50 --> No URI present. Default controller set.
DEBUG - 2024-07-07 22:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-07 22:29:50 --> Total execution time: 0.1524
DEBUG - 2024-07-07 22:29:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-07 22:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-07 22:29:50 --> 404 Page Not Found: Faviconico/index
