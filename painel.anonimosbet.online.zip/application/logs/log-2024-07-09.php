<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-09 00:52:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 00:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 00:52:58 --> Total execution time: 0.1179
DEBUG - 2024-07-09 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:22:50 --> Total execution time: 0.1275
DEBUG - 2024-07-09 01:25:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:25:12 --> Total execution time: 0.2135
DEBUG - 2024-07-09 01:25:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:25:22 --> Total execution time: 0.1268
DEBUG - 2024-07-09 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:30:05 --> Total execution time: 0.0800
DEBUG - 2024-07-09 01:30:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:30:40 --> Total execution time: 0.1688
DEBUG - 2024-07-09 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 01:40:37 --> No URI present. Default controller set.
DEBUG - 2024-07-09 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 01:40:38 --> Total execution time: 0.2184
DEBUG - 2024-07-09 04:18:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 04:18:32 --> No URI present. Default controller set.
DEBUG - 2024-07-09 04:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 04:18:32 --> Total execution time: 0.3666
DEBUG - 2024-07-09 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 10:02:31 --> No URI present. Default controller set.
DEBUG - 2024-07-09 10:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 10:02:32 --> Total execution time: 0.5705
DEBUG - 2024-07-09 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 10:02:32 --> No URI present. Default controller set.
DEBUG - 2024-07-09 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 10:02:32 --> Total execution time: 0.3609
DEBUG - 2024-07-09 17:52:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 17:52:50 --> No URI present. Default controller set.
DEBUG - 2024-07-09 17:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 17:52:50 --> Total execution time: 0.3055
DEBUG - 2024-07-09 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 21:59:53 --> No URI present. Default controller set.
DEBUG - 2024-07-09 21:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-09 21:59:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/painel.fire777.online/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-09 21:59:54 --> Unable to connect to the database
DEBUG - 2024-07-09 21:59:55 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 21:59:55 --> No URI present. Default controller set.
DEBUG - 2024-07-09 21:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-09 21:59:55 --> Total execution time: 0.1088
DEBUG - 2024-07-09 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 22:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-09 22:00:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-09 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-09 22:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-09 22:00:07 --> 404 Page Not Found: Faviconico/index
