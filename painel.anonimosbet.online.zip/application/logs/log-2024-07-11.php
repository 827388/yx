<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-11 00:50:13 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 00:50:13 --> No URI present. Default controller set.
DEBUG - 2024-07-11 00:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 00:50:13 --> Total execution time: 0.0399
DEBUG - 2024-07-11 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 06:49:54 --> No URI present. Default controller set.
DEBUG - 2024-07-11 06:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 06:49:54 --> Total execution time: 0.0543
DEBUG - 2024-07-11 06:49:57 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 06:49:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-11 06:49:57 --> 404 Page Not Found: Static/admin
DEBUG - 2024-07-11 06:50:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 06:50:29 --> No URI present. Default controller set.
DEBUG - 2024-07-11 06:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 06:50:29 --> Total execution time: 0.0332
DEBUG - 2024-07-11 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 06:50:38 --> No URI present. Default controller set.
DEBUG - 2024-07-11 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 06:50:38 --> Total execution time: 0.0373
DEBUG - 2024-07-11 18:14:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:40 --> No URI present. Default controller set.
DEBUG - 2024-07-11 18:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:40 --> Total execution time: 0.0665
DEBUG - 2024-07-11 18:14:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:47 --> Total execution time: 0.0445
DEBUG - 2024-07-11 18:14:55 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:56 --> Total execution time: 0.0526
DEBUG - 2024-07-11 18:14:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:14:58 --> Total execution time: 0.0444
DEBUG - 2024-07-11 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 18:50:13 --> No URI present. Default controller set.
DEBUG - 2024-07-11 18:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 18:50:13 --> Total execution time: 0.0349
DEBUG - 2024-07-11 19:28:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 19:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 19:28:37 --> Total execution time: 0.0455
DEBUG - 2024-07-11 21:57:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 21:57:18 --> No URI present. Default controller set.
DEBUG - 2024-07-11 21:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 21:57:18 --> Total execution time: 0.0439
DEBUG - 2024-07-11 22:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 22:13:39 --> No URI present. Default controller set.
DEBUG - 2024-07-11 22:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 22:13:39 --> Total execution time: 0.0399
DEBUG - 2024-07-11 23:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 23:19:52 --> No URI present. Default controller set.
DEBUG - 2024-07-11 23:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-11 23:19:52 --> Total execution time: 0.0369
DEBUG - 2024-07-11 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-11 23:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-11 23:19:54 --> 404 Page Not Found: Faviconico/index
