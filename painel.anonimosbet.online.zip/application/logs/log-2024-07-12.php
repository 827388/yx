<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-12 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:09 --> No URI present. Default controller set.
DEBUG - 2024-07-12 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:09 --> Total execution time: 0.0528
DEBUG - 2024-07-12 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:22 --> Total execution time: 0.0417
DEBUG - 2024-07-12 01:41:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:28 --> No URI present. Default controller set.
DEBUG - 2024-07-12 01:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:28 --> Total execution time: 0.0321
DEBUG - 2024-07-12 01:41:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:34 --> Total execution time: 0.0397
DEBUG - 2024-07-12 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:41 --> Total execution time: 0.0370
DEBUG - 2024-07-12 01:41:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:42 --> Total execution time: 0.0370
DEBUG - 2024-07-12 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:48 --> Total execution time: 0.0409
DEBUG - 2024-07-12 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:50 --> Total execution time: 0.0416
DEBUG - 2024-07-12 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 01:41:52 --> Total execution time: 0.0386
DEBUG - 2024-07-12 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 05:16:03 --> No URI present. Default controller set.
DEBUG - 2024-07-12 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 05:16:03 --> Total execution time: 0.0512
DEBUG - 2024-07-12 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 05:16:03 --> No URI present. Default controller set.
DEBUG - 2024-07-12 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 05:16:03 --> Total execution time: 0.0388
DEBUG - 2024-07-12 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 14:47:50 --> No URI present. Default controller set.
DEBUG - 2024-07-12 14:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 14:47:50 --> Total execution time: 0.0625
DEBUG - 2024-07-12 18:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 18:50:18 --> No URI present. Default controller set.
DEBUG - 2024-07-12 18:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 18:50:18 --> Total execution time: 0.0492
DEBUG - 2024-07-12 21:30:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 21:30:19 --> No URI present. Default controller set.
DEBUG - 2024-07-12 21:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-12 21:30:19 --> Total execution time: 0.0408
DEBUG - 2024-07-12 21:30:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-12 21:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-12 21:30:22 --> 404 Page Not Found: Faviconico/index
