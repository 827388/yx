<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-14 04:08:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 04:08:33 --> No URI present. Default controller set.
DEBUG - 2024-07-14 04:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 04:08:33 --> Total execution time: 0.0565
DEBUG - 2024-07-14 04:08:35 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 04:08:35 --> No URI present. Default controller set.
DEBUG - 2024-07-14 04:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 04:08:35 --> Total execution time: 0.0374
DEBUG - 2024-07-14 12:02:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:38 --> No URI present. Default controller set.
DEBUG - 2024-07-14 12:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 12:02:38 --> Total execution time: 0.0700
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
ERROR - 2024-07-14 12:02:53 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:54 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 12:02:54 --> UTF-8 Support Enabled
ERROR - 2024-07-14 12:02:54 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:02:54 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:12 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:13 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:13 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:13 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:13 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:28 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:30 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:30 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:30 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:32 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:44 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:45 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:45 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:45 --> 404 Page Not Found: Painelmmopragmaticsite/public
DEBUG - 2024-07-14 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-14 12:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-14 12:03:45 --> 404 Page Not Found: Painelmmopragmaticsite/public
