<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-15 07:54:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-15 07:54:36 --> No URI present. Default controller set.
DEBUG - 2024-07-15 07:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-15 07:54:36 --> Total execution time: 0.0670
DEBUG - 2024-07-15 07:54:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-15 07:54:36 --> No URI present. Default controller set.
DEBUG - 2024-07-15 07:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-15 07:54:37 --> Total execution time: 0.0370
