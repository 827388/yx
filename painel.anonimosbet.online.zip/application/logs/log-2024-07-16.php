<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-16 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:00:29 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:00:29 --> Total execution time: 0.0704
DEBUG - 2024-07-16 11:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:00:30 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:00:30 --> Total execution time: 0.0365
DEBUG - 2024-07-16 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:00:46 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:00:46 --> Total execution time: 0.0510
DEBUG - 2024-07-16 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:00:51 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:00:51 --> Total execution time: 0.0408
DEBUG - 2024-07-16 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:01:00 --> Total execution time: 0.0773
DEBUG - 2024-07-16 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:01:11 --> Total execution time: 0.0527
DEBUG - 2024-07-16 11:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:01:12 --> Total execution time: 0.0470
DEBUG - 2024-07-16 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:01:18 --> Total execution time: 0.0476
DEBUG - 2024-07-16 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:04:31 --> Total execution time: 0.0482
DEBUG - 2024-07-16 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:04:32 --> Total execution time: 0.0446
DEBUG - 2024-07-16 11:04:43 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:04:43 --> Total execution time: 0.0479
DEBUG - 2024-07-16 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:04:59 --> Total execution time: 0.0491
DEBUG - 2024-07-16 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:12 --> Total execution time: 0.0611
DEBUG - 2024-07-16 11:05:14 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:14 --> Total execution time: 0.0417
DEBUG - 2024-07-16 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:15 --> Total execution time: 0.0486
DEBUG - 2024-07-16 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:15 --> Total execution time: 0.0412
DEBUG - 2024-07-16 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:33 --> Total execution time: 0.0532
DEBUG - 2024-07-16 11:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:34 --> Total execution time: 0.0457
DEBUG - 2024-07-16 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:47 --> Total execution time: 0.0439
DEBUG - 2024-07-16 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:48 --> Total execution time: 0.0560
DEBUG - 2024-07-16 11:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:50 --> Total execution time: 0.0449
DEBUG - 2024-07-16 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:05:58 --> Total execution time: 0.0511
DEBUG - 2024-07-16 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:10:42 --> Total execution time: 0.0443
DEBUG - 2024-07-16 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:10:42 --> Total execution time: 0.0403
DEBUG - 2024-07-16 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:14:26 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:14:26 --> Total execution time: 0.0468
DEBUG - 2024-07-16 11:17:51 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:54 --> Total execution time: 0.0345
DEBUG - 2024-07-16 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:54 --> Total execution time: 0.0399
DEBUG - 2024-07-16 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:17:56 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:17:56 --> Total execution time: 0.0342
DEBUG - 2024-07-16 11:18:05 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:05 --> Total execution time: 0.0440
DEBUG - 2024-07-16 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:07 --> Total execution time: 0.0404
DEBUG - 2024-07-16 11:18:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:08 --> Total execution time: 0.0480
DEBUG - 2024-07-16 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:09 --> Total execution time: 0.0378
DEBUG - 2024-07-16 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:09 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:09 --> Total execution time: 0.0367
DEBUG - 2024-07-16 11:18:09 --> Total execution time: 0.0385
DEBUG - 2024-07-16 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:25 --> Total execution time: 0.0452
DEBUG - 2024-07-16 11:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:26 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:26 --> Total execution time: 0.0393
DEBUG - 2024-07-16 11:18:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:28 --> Total execution time: 0.0413
DEBUG - 2024-07-16 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:30 --> Total execution time: 0.0402
DEBUG - 2024-07-16 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:31 --> Total execution time: 0.0369
DEBUG - 2024-07-16 11:18:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:32 --> No URI present. Default controller set.
DEBUG - 2024-07-16 11:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:32 --> Total execution time: 0.0349
DEBUG - 2024-07-16 11:18:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:33 --> Total execution time: 0.0398
DEBUG - 2024-07-16 11:18:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:33 --> Total execution time: 0.0382
DEBUG - 2024-07-16 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:18:35 --> Total execution time: 0.0413
DEBUG - 2024-07-16 11:37:55 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 11:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 11:37:55 --> Total execution time: 0.0440
DEBUG - 2024-07-16 23:35:24 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 23:35:24 --> No URI present. Default controller set.
DEBUG - 2024-07-16 23:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 23:35:24 --> Total execution time: 0.0732
DEBUG - 2024-07-16 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 23:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 23:35:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 23:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 23:35:29 --> Total execution time: 0.0473
DEBUG - 2024-07-16 23:35:31 --> UTF-8 Support Enabled
DEBUG - 2024-07-16 23:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-16 23:35:31 --> Total execution time: 0.0445
