<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-17 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 00:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 00:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 00:32:42 --> Total execution time: 0.0356
DEBUG - 2024-07-17 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:57:46 --> No URI present. Default controller set.
DEBUG - 2024-07-17 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:57:46 --> Total execution time: 0.0413
DEBUG - 2024-07-17 10:57:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:57:52 --> Total execution time: 0.0665
DEBUG - 2024-07-17 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:57:53 --> Total execution time: 0.0490
DEBUG - 2024-07-17 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:58:01 --> Total execution time: 0.0566
DEBUG - 2024-07-17 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:58:04 --> Total execution time: 0.0546
DEBUG - 2024-07-17 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 10:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 10:58:17 --> Total execution time: 0.0593
DEBUG - 2024-07-17 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 12:31:21 --> No URI present. Default controller set.
DEBUG - 2024-07-17 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 12:31:21 --> Total execution time: 0.0447
DEBUG - 2024-07-17 12:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 12:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 12:31:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 12:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 12:31:32 --> Total execution time: 0.0427
DEBUG - 2024-07-17 12:31:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 12:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 12:31:40 --> Total execution time: 0.0479
DEBUG - 2024-07-17 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 12:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 12:31:50 --> Total execution time: 0.0473
DEBUG - 2024-07-17 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:33:41 --> No URI present. Default controller set.
DEBUG - 2024-07-17 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:33:41 --> Total execution time: 0.0408
DEBUG - 2024-07-17 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:33:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:33:45 --> Total execution time: 0.0505
DEBUG - 2024-07-17 14:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:33:47 --> Total execution time: 0.0572
DEBUG - 2024-07-17 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:34:23 --> Total execution time: 0.0463
DEBUG - 2024-07-17 14:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 14:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 14:34:28 --> Total execution time: 0.0473
DEBUG - 2024-07-17 20:31:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:31:03 --> No URI present. Default controller set.
DEBUG - 2024-07-17 20:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:31:03 --> Total execution time: 0.0703
DEBUG - 2024-07-17 20:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:33:37 --> No URI present. Default controller set.
DEBUG - 2024-07-17 20:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:33:37 --> Total execution time: 0.0421
DEBUG - 2024-07-17 20:33:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:33:45 --> No URI present. Default controller set.
DEBUG - 2024-07-17 20:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:33:45 --> Total execution time: 0.0342
DEBUG - 2024-07-17 20:36:43 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:36:43 --> No URI present. Default controller set.
DEBUG - 2024-07-17 20:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:36:43 --> Total execution time: 0.0383
DEBUG - 2024-07-17 20:36:51 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:36:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:36:53 --> Total execution time: 0.0427
DEBUG - 2024-07-17 20:37:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:04 --> Total execution time: 0.0420
DEBUG - 2024-07-17 20:37:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:12 --> Total execution time: 0.0594
DEBUG - 2024-07-17 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:17 --> Total execution time: 0.0473
DEBUG - 2024-07-17 20:37:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-17 20:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-17 20:37:20 --> Total execution time: 0.0506
