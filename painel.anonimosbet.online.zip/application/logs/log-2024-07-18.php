<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-18 00:05:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:29 --> No URI present. Default controller set.
DEBUG - 2024-07-18 00:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:29 --> Total execution time: 0.0404
DEBUG - 2024-07-18 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:35 --> Total execution time: 0.0481
DEBUG - 2024-07-18 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:37 --> Total execution time: 0.0416
DEBUG - 2024-07-18 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:37 --> Total execution time: 0.0443
DEBUG - 2024-07-18 00:05:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:05:41 --> Total execution time: 0.0523
DEBUG - 2024-07-18 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:12:03 --> Total execution time: 0.0735
DEBUG - 2024-07-18 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:16:37 --> Total execution time: 0.0428
DEBUG - 2024-07-18 00:17:06 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:17:06 --> Total execution time: 0.0526
DEBUG - 2024-07-18 00:17:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:17:26 --> Total execution time: 0.0487
DEBUG - 2024-07-18 00:18:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:18:38 --> Total execution time: 0.0440
DEBUG - 2024-07-18 00:18:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:18:40 --> Total execution time: 0.0399
DEBUG - 2024-07-18 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:18:58 --> Total execution time: 0.0393
DEBUG - 2024-07-18 00:20:16 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:20:16 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:20:16 --> Total execution time: 0.0391
DEBUG - 2024-07-18 00:20:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:20:34 --> Total execution time: 0.0363
DEBUG - 2024-07-18 00:23:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:23:20 --> Total execution time: 0.0416
DEBUG - 2024-07-18 00:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:23:58 --> Total execution time: 0.0423
DEBUG - 2024-07-18 00:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:24:40 --> Total execution time: 0.0544
DEBUG - 2024-07-18 00:24:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:24:42 --> Total execution time: 0.0393
DEBUG - 2024-07-18 00:25:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:25:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:25:42 --> Total execution time: 0.0354
DEBUG - 2024-07-18 00:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:26:04 --> Total execution time: 0.0411
DEBUG - 2024-07-18 00:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:28:33 --> No URI present. Default controller set.
DEBUG - 2024-07-18 00:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:28:33 --> Total execution time: 0.0372
DEBUG - 2024-07-18 00:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 00:28:40 --> No URI present. Default controller set.
DEBUG - 2024-07-18 00:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 00:28:40 --> Total execution time: 0.0365
DEBUG - 2024-07-18 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 10:34:26 --> No URI present. Default controller set.
DEBUG - 2024-07-18 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 10:34:26 --> Total execution time: 0.0526
DEBUG - 2024-07-18 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 13:26:59 --> No URI present. Default controller set.
DEBUG - 2024-07-18 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 13:26:59 --> Total execution time: 0.0442
DEBUG - 2024-07-18 15:59:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 15:59:22 --> No URI present. Default controller set.
DEBUG - 2024-07-18 15:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 15:59:22 --> Total execution time: 0.0438
DEBUG - 2024-07-18 15:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 15:59:28 --> No URI present. Default controller set.
DEBUG - 2024-07-18 15:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 15:59:28 --> Total execution time: 0.0390
DEBUG - 2024-07-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:10 --> No URI present. Default controller set.
DEBUG - 2024-07-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:10 --> Total execution time: 0.0506
DEBUG - 2024-07-18 16:16:14 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:15 --> Total execution time: 0.0582
DEBUG - 2024-07-18 16:16:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:18 --> Total execution time: 0.0453
DEBUG - 2024-07-18 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:20 --> Total execution time: 0.0411
DEBUG - 2024-07-18 16:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 16:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 16:16:38 --> Total execution time: 0.0434
DEBUG - 2024-07-18 21:05:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 21:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 21:05:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 21:05:22 --> No URI present. Default controller set.
DEBUG - 2024-07-18 21:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 21:05:22 --> Total execution time: 0.0410
DEBUG - 2024-07-18 21:05:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 21:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 21:05:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 21:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 21:05:26 --> Total execution time: 0.0430
DEBUG - 2024-07-18 21:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-18 21:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-18 21:05:28 --> Total execution time: 0.0461
