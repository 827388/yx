<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-19 13:28:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 13:28:53 --> No URI present. Default controller set.
DEBUG - 2024-07-19 13:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 13:28:53 --> Total execution time: 0.0679
DEBUG - 2024-07-19 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 13:28:55 --> No URI present. Default controller set.
DEBUG - 2024-07-19 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 13:28:55 --> Total execution time: 0.0422
DEBUG - 2024-07-19 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 13:29:01 --> Total execution time: 0.0767
DEBUG - 2024-07-19 14:20:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:20:48 --> No URI present. Default controller set.
DEBUG - 2024-07-19 14:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:20:48 --> Total execution time: 0.0473
DEBUG - 2024-07-19 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:20:53 --> Total execution time: 0.0435
DEBUG - 2024-07-19 14:21:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:00 --> Total execution time: 0.0599
DEBUG - 2024-07-19 14:21:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:08 --> Total execution time: 0.0421
DEBUG - 2024-07-19 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:17 --> Total execution time: 0.0409
DEBUG - 2024-07-19 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:20 --> Total execution time: 0.0439
DEBUG - 2024-07-19 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:34 --> Total execution time: 0.0459
DEBUG - 2024-07-19 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:47 --> Total execution time: 0.0421
DEBUG - 2024-07-19 14:21:51 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:21:52 --> Total execution time: 0.0378
DEBUG - 2024-07-19 14:22:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 14:22:00 --> No URI present. Default controller set.
DEBUG - 2024-07-19 14:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 14:22:00 --> Total execution time: 0.0347
DEBUG - 2024-07-19 16:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:58:15 --> No URI present. Default controller set.
DEBUG - 2024-07-19 16:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:58:15 --> Total execution time: 0.0382
DEBUG - 2024-07-19 16:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:58:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:58:37 --> Total execution time: 0.0428
DEBUG - 2024-07-19 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:58:48 --> Total execution time: 0.0386
DEBUG - 2024-07-19 16:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:59:16 --> Total execution time: 0.0506
DEBUG - 2024-07-19 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:59:29 --> Total execution time: 0.0406
DEBUG - 2024-07-19 16:59:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-19 16:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-19 16:59:45 --> Total execution time: 0.0425
