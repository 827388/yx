<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-20 09:52:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:52:45 --> No URI present. Default controller set.
DEBUG - 2024-07-20 09:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:52:45 --> Total execution time: 0.0600
DEBUG - 2024-07-20 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:52:53 --> Total execution time: 0.0604
DEBUG - 2024-07-20 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:52:56 --> Total execution time: 0.0444
DEBUG - 2024-07-20 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:53:01 --> Total execution time: 0.0524
DEBUG - 2024-07-20 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:53:04 --> Total execution time: 0.0507
DEBUG - 2024-07-20 09:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:53:11 --> Total execution time: 0.0421
DEBUG - 2024-07-20 09:53:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:53:15 --> Total execution time: 0.0554
DEBUG - 2024-07-20 09:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:53:19 --> Total execution time: 0.0423
DEBUG - 2024-07-20 09:54:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:40 --> Total execution time: 0.0391
DEBUG - 2024-07-20 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:41 --> Total execution time: 0.0424
DEBUG - 2024-07-20 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:43 --> Total execution time: 0.0400
DEBUG - 2024-07-20 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:46 --> Total execution time: 0.0380
DEBUG - 2024-07-20 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:49 --> Total execution time: 0.0426
DEBUG - 2024-07-20 09:54:50 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:50 --> Total execution time: 0.0371
DEBUG - 2024-07-20 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:53 --> No URI present. Default controller set.
DEBUG - 2024-07-20 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:53 --> Total execution time: 0.0330
DEBUG - 2024-07-20 09:54:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:54:57 --> Total execution time: 0.0377
DEBUG - 2024-07-20 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:01 --> Total execution time: 0.0781
DEBUG - 2024-07-20 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:06 --> Total execution time: 0.0495
DEBUG - 2024-07-20 09:55:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:08 --> Total execution time: 0.0495
DEBUG - 2024-07-20 09:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:34 --> No URI present. Default controller set.
DEBUG - 2024-07-20 09:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:34 --> Total execution time: 0.0327
DEBUG - 2024-07-20 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:40 --> Total execution time: 0.0444
DEBUG - 2024-07-20 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:45 --> Total execution time: 0.0348
DEBUG - 2024-07-20 09:55:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 09:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-20 09:55:49 --> Total execution time: 0.0378
DEBUG - 2024-07-20 11:30:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-20 11:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-20 11:30:56 --> 404 Page Not Found: Env/index
