<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-22 20:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-22 20:44:47 --> No URI present. Default controller set.
DEBUG - 2024-07-22 20:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-22 20:44:47 --> Total execution time: 0.0724
DEBUG - 2024-07-22 20:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-22 20:47:54 --> No URI present. Default controller set.
DEBUG - 2024-07-22 20:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-22 20:47:54 --> Total execution time: 0.0431
DEBUG - 2024-07-22 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-22 23:54:36 --> No URI present. Default controller set.
DEBUG - 2024-07-22 23:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-22 23:54:36 --> Total execution time: 0.0380
