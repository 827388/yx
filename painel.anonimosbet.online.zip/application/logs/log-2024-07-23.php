<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-23 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:12:02 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-23 15:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'pragmatic'@'localhost' (using password: YES) /www/wwwroot/painel.mmopragmatic.site/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-23 15:12:02 --> Unable to connect to the database
DEBUG - 2024-07-23 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:12:02 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-23 15:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'pragmatic'@'localhost' (using password: YES) /www/wwwroot/painel.mmopragmatic.site/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-07-23 15:12:02 --> Unable to connect to the database
DEBUG - 2024-07-23 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-23 15:12:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-07-23 15:12:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:12:42 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:12:42 --> Total execution time: 0.0628
DEBUG - 2024-07-23 15:13:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:13:54 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:13:54 --> Total execution time: 0.0535
DEBUG - 2024-07-23 15:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:14:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:14:03 --> Total execution time: 0.0531
DEBUG - 2024-07-23 15:14:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:14:04 --> Total execution time: 0.0485
DEBUG - 2024-07-23 15:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:14:22 --> Total execution time: 0.0481
DEBUG - 2024-07-23 15:17:06 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:17:06 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:17:06 --> Total execution time: 0.0450
DEBUG - 2024-07-23 15:23:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:23:12 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:23:12 --> Total execution time: 0.0414
DEBUG - 2024-07-23 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:35:33 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:35:33 --> Total execution time: 0.0419
DEBUG - 2024-07-23 15:45:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:45:17 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:45:17 --> Total execution time: 0.0416
DEBUG - 2024-07-23 15:45:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:45:17 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:45:17 --> Total execution time: 0.0397
DEBUG - 2024-07-23 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 15:45:18 --> No URI present. Default controller set.
DEBUG - 2024-07-23 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 15:45:18 --> Total execution time: 0.0419
DEBUG - 2024-07-23 16:06:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:12 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:12 --> Total execution time: 0.0464
DEBUG - 2024-07-23 16:06:18 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:19 --> Total execution time: 0.0417
DEBUG - 2024-07-23 16:06:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:23 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:23 --> Total execution time: 0.0440
DEBUG - 2024-07-23 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:27 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:27 --> Total execution time: 0.0492
DEBUG - 2024-07-23 16:06:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:32 --> Total execution time: 0.0423
DEBUG - 2024-07-23 16:06:39 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:39 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:39 --> Total execution time: 0.0453
DEBUG - 2024-07-23 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:06:42 --> Total execution time: 0.0437
DEBUG - 2024-07-23 16:07:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:03 --> Total execution time: 0.0535
DEBUG - 2024-07-23 16:07:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:09 --> Total execution time: 0.0671
DEBUG - 2024-07-23 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:21 --> Total execution time: 0.0445
DEBUG - 2024-07-23 16:07:24 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:24 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:24 --> Total execution time: 0.0482
DEBUG - 2024-07-23 16:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:25 --> Total execution time: 0.0802
DEBUG - 2024-07-23 16:07:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:28 --> Total execution time: 0.0451
DEBUG - 2024-07-23 16:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:07:34 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:07:34 --> Total execution time: 0.0395
DEBUG - 2024-07-23 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:08:49 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:08:49 --> Total execution time: 0.0441
DEBUG - 2024-07-23 16:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:09 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:09 --> Total execution time: 0.0459
DEBUG - 2024-07-23 16:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:13 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:13 --> Total execution time: 0.0387
DEBUG - 2024-07-23 16:09:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:36 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:36 --> Total execution time: 0.0398
DEBUG - 2024-07-23 16:09:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:53 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:53 --> Total execution time: 0.0433
DEBUG - 2024-07-23 16:09:57 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:09:57 --> Total execution time: 0.0437
DEBUG - 2024-07-23 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:46:54 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:46:55 --> Total execution time: 0.0426
DEBUG - 2024-07-23 16:47:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:04 --> Total execution time: 0.0492
DEBUG - 2024-07-23 16:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:08 --> Total execution time: 0.0461
DEBUG - 2024-07-23 16:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:08 --> Total execution time: 0.0575
DEBUG - 2024-07-23 16:47:10 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:10 --> Total execution time: 0.0605
DEBUG - 2024-07-23 16:47:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:47:11 --> Total execution time: 0.0474
DEBUG - 2024-07-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:48:30 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:48:31 --> Total execution time: 0.0516
DEBUG - 2024-07-23 16:48:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:48:36 --> Total execution time: 0.0392
DEBUG - 2024-07-23 16:48:39 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:48:39 --> Total execution time: 0.0393
DEBUG - 2024-07-23 16:49:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:49:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:49:12 --> Total execution time: 0.0438
DEBUG - 2024-07-23 16:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:49:28 --> Total execution time: 0.0470
DEBUG - 2024-07-23 16:49:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:49:31 --> Total execution time: 0.0474
DEBUG - 2024-07-23 16:54:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 16:54:07 --> No URI present. Default controller set.
DEBUG - 2024-07-23 16:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 16:54:07 --> Total execution time: 0.0468
DEBUG - 2024-07-23 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 17:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 17:38:02 --> Total execution time: 0.0609
DEBUG - 2024-07-23 21:39:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:11 --> No URI present. Default controller set.
DEBUG - 2024-07-23 21:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:11 --> Total execution time: 0.0403
DEBUG - 2024-07-23 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:14 --> No URI present. Default controller set.
DEBUG - 2024-07-23 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:14 --> Total execution time: 0.0317
DEBUG - 2024-07-23 21:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:17 --> Total execution time: 0.0424
DEBUG - 2024-07-23 21:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:32 --> Total execution time: 0.0386
DEBUG - 2024-07-23 21:39:35 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:39:35 --> Total execution time: 0.0361
DEBUG - 2024-07-23 21:45:23 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:23 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:23 --> Total execution time: 0.0377
DEBUG - 2024-07-23 21:45:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:28 --> Total execution time: 0.0466
DEBUG - 2024-07-23 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:30 --> Total execution time: 0.0374
DEBUG - 2024-07-23 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:45:30 --> Total execution time: 0.0374
DEBUG - 2024-07-23 21:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:46:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:46:33 --> Total execution time: 0.0353
DEBUG - 2024-07-23 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:47:04 --> Total execution time: 0.0408
DEBUG - 2024-07-23 21:47:05 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:47:05 --> Total execution time: 0.0374
DEBUG - 2024-07-23 21:47:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:47:07 --> Total execution time: 0.0441
DEBUG - 2024-07-23 21:47:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:47:12 --> Total execution time: 0.0379
DEBUG - 2024-07-23 21:56:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:56:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-23 21:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-23 21:56:19 --> Total execution time: 0.0411
