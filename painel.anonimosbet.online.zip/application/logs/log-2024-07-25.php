<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-25 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2024-07-25 01:58:22 --> No URI present. Default controller set.
DEBUG - 2024-07-25 01:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-25 01:58:22 --> Total execution time: 0.0393
DEBUG - 2024-07-25 01:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-25 01:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-25 01:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-07-25 01:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-25 01:58:26 --> Total execution time: 0.0372
DEBUG - 2024-07-25 01:58:31 --> UTF-8 Support Enabled
DEBUG - 2024-07-25 01:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-25 01:58:31 --> Total execution time: 0.0427
