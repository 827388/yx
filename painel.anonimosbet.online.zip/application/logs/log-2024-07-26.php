<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-26 02:11:55 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:11:55 --> No URI present. Default controller set.
DEBUG - 2024-07-26 02:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 02:11:55 --> Total execution time: 0.0598
DEBUG - 2024-07-26 02:12:14 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-26 02:12:14 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-07-26 02:12:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-26 02:12:15 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-26 02:12:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-26 02:12:17 --> 404 Page Not Found: Configjson/index
DEBUG - 2024-07-26 02:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:13:15 --> No URI present. Default controller set.
DEBUG - 2024-07-26 02:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 02:13:15 --> Total execution time: 0.0380
DEBUG - 2024-07-26 02:13:16 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-26 02:13:16 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-26 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:14:51 --> No URI present. Default controller set.
DEBUG - 2024-07-26 02:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 02:14:51 --> Total execution time: 0.0336
DEBUG - 2024-07-26 02:14:56 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 02:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-26 02:14:56 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-26 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 13:35:03 --> No URI present. Default controller set.
DEBUG - 2024-07-26 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 13:35:03 --> Total execution time: 0.0934
DEBUG - 2024-07-26 13:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 13:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 13:35:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 13:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 13:35:07 --> Total execution time: 0.0472
DEBUG - 2024-07-26 13:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-26 13:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-26 13:35:48 --> Total execution time: 0.0460
