<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-27 12:23:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-27 12:23:12 --> No URI present. Default controller set.
DEBUG - 2024-07-27 12:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-27 12:23:12 --> Total execution time: 0.0767
DEBUG - 2024-07-27 12:23:12 --> UTF-8 Support Enabled
DEBUG - 2024-07-27 12:23:12 --> No URI present. Default controller set.
DEBUG - 2024-07-27 12:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-27 12:23:13 --> Total execution time: 0.0381
