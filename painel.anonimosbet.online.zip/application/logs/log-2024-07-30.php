<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-30 12:02:24 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 12:02:24 --> No URI present. Default controller set.
DEBUG - 2024-07-30 12:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 12:02:24 --> Total execution time: 0.0821
DEBUG - 2024-07-30 12:02:47 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 12:02:47 --> No URI present. Default controller set.
DEBUG - 2024-07-30 12:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 12:02:47 --> Total execution time: 0.0421
DEBUG - 2024-07-30 20:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 20:35:09 --> No URI present. Default controller set.
DEBUG - 2024-07-30 20:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 20:35:09 --> Total execution time: 0.0466
DEBUG - 2024-07-30 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 20:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 20:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 20:35:17 --> Total execution time: 0.0443
DEBUG - 2024-07-30 20:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-07-30 20:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-30 20:35:49 --> Total execution time: 0.0430
