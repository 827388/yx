<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-07-31 01:21:33 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:21:33 --> No URI present. Default controller set.
DEBUG - 2024-07-31 01:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:21:33 --> Total execution time: 0.0472
DEBUG - 2024-07-31 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:21:39 --> Total execution time: 0.0365
DEBUG - 2024-07-31 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:21:52 --> Total execution time: 0.0432
DEBUG - 2024-07-31 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:21:58 --> Total execution time: 0.0348
DEBUG - 2024-07-31 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:22:00 --> Total execution time: 0.0467
DEBUG - 2024-07-31 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:22:00 --> Total execution time: 0.0435
DEBUG - 2024-07-31 01:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:22:08 --> Total execution time: 0.0355
DEBUG - 2024-07-31 01:23:08 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:23:08 --> Total execution time: 0.0436
DEBUG - 2024-07-31 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:23:11 --> Total execution time: 0.0438
DEBUG - 2024-07-31 01:23:28 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:23:28 --> Total execution time: 0.0412
DEBUG - 2024-07-31 01:23:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:23:32 --> Total execution time: 0.0374
DEBUG - 2024-07-31 01:23:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:23:34 --> Total execution time: 0.0404
DEBUG - 2024-07-31 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 01:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 01:24:37 --> Total execution time: 0.0428
DEBUG - 2024-07-31 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:41:00 --> No URI present. Default controller set.
DEBUG - 2024-07-31 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 05:41:00 --> Total execution time: 0.0366
DEBUG - 2024-07-31 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:41:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-07-31 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:41:05 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-31 05:42:02 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:02 --> No URI present. Default controller set.
DEBUG - 2024-07-31 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 05:42:03 --> Total execution time: 0.0401
DEBUG - 2024-07-31 05:42:07 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:42:07 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-31 05:42:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:25 --> No URI present. Default controller set.
DEBUG - 2024-07-31 05:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 05:42:25 --> Total execution time: 0.0326
DEBUG - 2024-07-31 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:42:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-07-31 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:42:46 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-07-31 05:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 05:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-07-31 05:42:48 --> 404 Page Not Found: Configjson/index
DEBUG - 2024-07-31 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 07:31:41 --> No URI present. Default controller set.
DEBUG - 2024-07-31 07:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 07:31:41 --> Total execution time: 0.0364
DEBUG - 2024-07-31 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 07:31:41 --> No URI present. Default controller set.
DEBUG - 2024-07-31 07:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 07:31:41 --> Total execution time: 0.0341
DEBUG - 2024-07-31 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 10:14:34 --> No URI present. Default controller set.
DEBUG - 2024-07-31 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 10:14:34 --> Total execution time: 0.0375
DEBUG - 2024-07-31 18:04:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 18:04:58 --> No URI present. Default controller set.
DEBUG - 2024-07-31 18:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 18:04:58 --> Total execution time: 0.0805
DEBUG - 2024-07-31 20:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 20:49:19 --> No URI present. Default controller set.
DEBUG - 2024-07-31 20:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 20:49:19 --> Total execution time: 0.0428
DEBUG - 2024-07-31 20:49:25 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 20:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 20:49:27 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 20:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 20:49:27 --> Total execution time: 0.0639
DEBUG - 2024-07-31 20:49:32 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 20:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 20:49:32 --> Total execution time: 0.0467
DEBUG - 2024-07-31 20:49:35 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 20:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 20:49:35 --> Total execution time: 0.0541
DEBUG - 2024-07-31 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 23:02:54 --> No URI present. Default controller set.
DEBUG - 2024-07-31 23:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 23:02:54 --> Total execution time: 0.0412
DEBUG - 2024-07-31 23:02:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 23:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 23:02:58 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 23:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 23:02:58 --> Total execution time: 0.0364
DEBUG - 2024-07-31 23:03:00 --> UTF-8 Support Enabled
DEBUG - 2024-07-31 23:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-07-31 23:03:00 --> Total execution time: 0.0393
