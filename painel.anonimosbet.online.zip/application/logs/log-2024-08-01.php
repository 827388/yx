<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-01 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:04:23 --> No URI present. Default controller set.
DEBUG - 2024-08-01 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:04:23 --> Total execution time: 0.0373
DEBUG - 2024-08-01 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:04:34 --> Total execution time: 0.0415
DEBUG - 2024-08-01 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:04:37 --> Total execution time: 0.0402
DEBUG - 2024-08-01 14:34:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:34:45 --> No URI present. Default controller set.
DEBUG - 2024-08-01 14:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:34:45 --> Total execution time: 0.0367
DEBUG - 2024-08-01 14:35:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 14:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 14:35:28 --> Total execution time: 0.0438
DEBUG - 2024-08-01 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:01:30 --> No URI present. Default controller set.
DEBUG - 2024-08-01 15:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:01:30 --> Total execution time: 0.0392
DEBUG - 2024-08-01 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:01:30 --> No URI present. Default controller set.
DEBUG - 2024-08-01 15:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:01:30 --> Total execution time: 0.0390
DEBUG - 2024-08-01 15:01:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:01:43 --> No URI present. Default controller set.
DEBUG - 2024-08-01 15:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:01:43 --> Total execution time: 0.0394
DEBUG - 2024-08-01 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:02:00 --> Total execution time: 0.0513
DEBUG - 2024-08-01 15:02:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:02:28 --> Total execution time: 0.0459
DEBUG - 2024-08-01 15:02:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 15:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 15:02:32 --> Total execution time: 0.0391
DEBUG - 2024-08-01 16:54:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:11 --> No URI present. Default controller set.
DEBUG - 2024-08-01 16:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:11 --> Total execution time: 0.0362
DEBUG - 2024-08-01 16:54:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:18 --> Total execution time: 0.0418
DEBUG - 2024-08-01 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:24 --> Total execution time: 0.0384
DEBUG - 2024-08-01 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:26 --> No URI present. Default controller set.
DEBUG - 2024-08-01 16:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:26 --> Total execution time: 0.0332
DEBUG - 2024-08-01 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:30 --> Total execution time: 0.0425
DEBUG - 2024-08-01 16:54:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:35 --> Total execution time: 0.0394
DEBUG - 2024-08-01 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 16:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 16:54:44 --> Total execution time: 0.0383
DEBUG - 2024-08-01 20:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:09:10 --> No URI present. Default controller set.
DEBUG - 2024-08-01 20:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:09:10 --> Total execution time: 0.0443
DEBUG - 2024-08-01 20:12:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:22 --> Total execution time: 0.0390
DEBUG - 2024-08-01 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:27 --> Total execution time: 0.0375
DEBUG - 2024-08-01 20:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:31 --> Total execution time: 0.0398
DEBUG - 2024-08-01 20:12:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:34 --> No URI present. Default controller set.
DEBUG - 2024-08-01 20:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:34 --> Total execution time: 0.0387
DEBUG - 2024-08-01 20:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:35 --> Total execution time: 0.0386
DEBUG - 2024-08-01 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:37 --> Total execution time: 0.0423
DEBUG - 2024-08-01 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:48 --> Total execution time: 0.0360
DEBUG - 2024-08-01 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:12:51 --> Total execution time: 0.0383
DEBUG - 2024-08-01 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:13:14 --> Total execution time: 0.0468
DEBUG - 2024-08-01 20:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:13:17 --> Total execution time: 0.0383
DEBUG - 2024-08-01 20:13:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:13:19 --> Total execution time: 0.0390
DEBUG - 2024-08-01 20:13:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:13:53 --> Total execution time: 0.0432
DEBUG - 2024-08-01 20:13:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-01 20:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-01 20:13:54 --> Total execution time: 0.0404
