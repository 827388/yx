<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-02 00:03:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:27 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:27 --> Total execution time: 0.0330
DEBUG - 2024-08-02 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:39 --> Total execution time: 0.0323
DEBUG - 2024-08-02 00:03:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:47 --> Total execution time: 0.0321
DEBUG - 2024-08-02 00:03:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:03:57 --> Total execution time: 0.0401
DEBUG - 2024-08-02 00:04:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:04:11 --> Total execution time: 0.0394
DEBUG - 2024-08-02 00:04:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 00:04:43 --> Query error: Column 'rtpgeral' cannot be null - Invalid query: INSERT INTO `agents` (`email`, `agentCode`, `password`, `token`, `secretKey`, `agentName`, `agentType`, `percent`, `balance`, `depth`, `parentId`, `currency`, `lang`, `createdAt`, `rtpgeral`) VALUES ('onofre@onofre.com', 'onofre', '$2y$10$SSOXckAJIcy0t9YHSLqI9.NQbzgeJjE7dnql0P6QhiBnfCd5Wtx7K', 'e47d7b9f43fde0a8d397e76dad3650cf', '2b3e714c16df9cb9f01cb2404d50f269', 'onofre', 2, 22, 0, 1, '1', 'BRL', 'pt', '2024-08-02 00:04:43', NULL)
DEBUG - 2024-08-02 00:04:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 00:04:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 00:04:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:04:49 --> Total execution time: 0.0368
DEBUG - 2024-08-02 00:04:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:04:55 --> Total execution time: 0.0369
DEBUG - 2024-08-02 00:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:06 --> Total execution time: 0.0375
DEBUG - 2024-08-02 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:08 --> Total execution time: 0.0378
DEBUG - 2024-08-02 00:05:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:26 --> Total execution time: 0.0435
DEBUG - 2024-08-02 00:05:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:33 --> Total execution time: 0.0361
DEBUG - 2024-08-02 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:47 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:47 --> Total execution time: 0.0339
DEBUG - 2024-08-02 00:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:05:57 --> Total execution time: 0.0388
DEBUG - 2024-08-02 00:06:04 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:06:05 --> Total execution time: 0.0361
DEBUG - 2024-08-02 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:06:36 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:06:36 --> Total execution time: 0.0356
DEBUG - 2024-08-02 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:06:47 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:06:47 --> Total execution time: 0.0332
DEBUG - 2024-08-02 00:09:04 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:04 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:04 --> Total execution time: 0.0347
DEBUG - 2024-08-02 00:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:24 --> Total execution time: 0.0413
DEBUG - 2024-08-02 00:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:24 --> Total execution time: 0.0353
DEBUG - 2024-08-02 00:09:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:26 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:26 --> Total execution time: 0.0315
DEBUG - 2024-08-02 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:41 --> Total execution time: 0.0368
DEBUG - 2024-08-02 00:09:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:46 --> Total execution time: 0.0367
DEBUG - 2024-08-02 00:09:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:56 --> Total execution time: 0.0367
DEBUG - 2024-08-02 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:09:58 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:09:58 --> Total execution time: 0.0321
DEBUG - 2024-08-02 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:10:06 --> Total execution time: 0.0373
DEBUG - 2024-08-02 00:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:10:17 --> Total execution time: 0.0378
DEBUG - 2024-08-02 00:20:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:20:59 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:20:59 --> Total execution time: 0.0350
DEBUG - 2024-08-02 00:21:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:15 --> Total execution time: 0.0381
DEBUG - 2024-08-02 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:33 --> Total execution time: 0.0367
DEBUG - 2024-08-02 00:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:36 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:36 --> Total execution time: 0.0363
DEBUG - 2024-08-02 00:21:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:42 --> Total execution time: 0.0414
DEBUG - 2024-08-02 00:21:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:54 --> Total execution time: 0.0373
DEBUG - 2024-08-02 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:21:59 --> Total execution time: 0.0344
DEBUG - 2024-08-02 00:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:22:29 --> Total execution time: 0.0368
DEBUG - 2024-08-02 00:23:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:23:22 --> Total execution time: 0.0354
DEBUG - 2024-08-02 00:24:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:24:53 --> Total execution time: 0.0374
DEBUG - 2024-08-02 00:25:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:08 --> Total execution time: 0.0441
DEBUG - 2024-08-02 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:14 --> Total execution time: 0.0415
DEBUG - 2024-08-02 00:25:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:32 --> Total execution time: 0.0424
DEBUG - 2024-08-02 00:25:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:33 --> Total execution time: 0.0335
DEBUG - 2024-08-02 00:25:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:33 --> Total execution time: 0.0454
DEBUG - 2024-08-02 00:25:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:34 --> Total execution time: 0.0339
DEBUG - 2024-08-02 00:25:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:35 --> Total execution time: 0.0328
DEBUG - 2024-08-02 00:25:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:35 --> Total execution time: 0.0328
DEBUG - 2024-08-02 00:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:36 --> Total execution time: 0.0392
DEBUG - 2024-08-02 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:37 --> Total execution time: 0.0348
DEBUG - 2024-08-02 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:37 --> Total execution time: 0.0335
DEBUG - 2024-08-02 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 00:25:37 --> No URI present. Default controller set.
DEBUG - 2024-08-02 00:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 00:25:37 --> Total execution time: 0.0325
DEBUG - 2024-08-02 02:39:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 02:39:14 --> No URI present. Default controller set.
DEBUG - 2024-08-02 02:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 02:39:14 --> Total execution time: 0.0473
DEBUG - 2024-08-02 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 03:17:51 --> No URI present. Default controller set.
DEBUG - 2024-08-02 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 03:17:51 --> Total execution time: 0.0368
DEBUG - 2024-08-02 03:17:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 03:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 03:17:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 03:17:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 03:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 03:17:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 03:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 03:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 03:17:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 07:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 07:18:09 --> No URI present. Default controller set.
DEBUG - 2024-08-02 07:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 07:18:09 --> Total execution time: 0.0645
DEBUG - 2024-08-02 07:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 07:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 07:18:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 07:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 07:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 07:18:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 07:18:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 07:18:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 08:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 08:33:47 --> No URI present. Default controller set.
DEBUG - 2024-08-02 08:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 08:33:47 --> Total execution time: 0.0447
DEBUG - 2024-08-02 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 08:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 08:33:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 08:33:50 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 08:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 08:33:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 10:03:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 10:03:55 --> No URI present. Default controller set.
DEBUG - 2024-08-02 10:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 10:03:55 --> Total execution time: 0.0447
DEBUG - 2024-08-02 10:03:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 10:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 10:03:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 10:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 10:03:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 10:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 10:03:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 15:25:51 --> No URI present. Default controller set.
DEBUG - 2024-08-02 15:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 15:25:51 --> Total execution time: 0.0675
DEBUG - 2024-08-02 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 15:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 15:25:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 15:25:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 15:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 15:25:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 16:17:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 16:17:32 --> No URI present. Default controller set.
DEBUG - 2024-08-02 16:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 16:17:32 --> Total execution time: 0.0434
DEBUG - 2024-08-02 16:17:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 16:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 16:17:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 16:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 16:17:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 16:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 16:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 16:17:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 21:15:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 21:15:14 --> No URI present. Default controller set.
DEBUG - 2024-08-02 21:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 21:15:14 --> Total execution time: 0.0462
DEBUG - 2024-08-02 21:28:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 21:28:05 --> No URI present. Default controller set.
DEBUG - 2024-08-02 21:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-02 21:28:05 --> Total execution time: 0.0392
DEBUG - 2024-08-02 21:28:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 21:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 21:28:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-02 21:28:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-02 21:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-02 21:28:07 --> 404 Page Not Found: Faviconico/index
