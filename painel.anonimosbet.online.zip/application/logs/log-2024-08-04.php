<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-04 04:22:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-04 04:22:53 --> No URI present. Default controller set.
DEBUG - 2024-08-04 04:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-04 04:22:53 --> Total execution time: 0.0544
DEBUG - 2024-08-04 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-04 04:22:54 --> No URI present. Default controller set.
DEBUG - 2024-08-04 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-04 04:22:54 --> Total execution time: 0.0358
DEBUG - 2024-08-04 21:16:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-04 21:16:25 --> No URI present. Default controller set.
DEBUG - 2024-08-04 21:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-04 21:16:25 --> Total execution time: 0.0544
