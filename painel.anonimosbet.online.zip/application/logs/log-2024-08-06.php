<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-06 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-06 11:35:07 --> No URI present. Default controller set.
DEBUG - 2024-08-06 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-06 11:35:07 --> Total execution time: 0.1000
