<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-07 00:20:04 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:04 --> No URI present. Default controller set.
DEBUG - 2024-08-07 00:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 00:20:04 --> Total execution time: 0.0823
DEBUG - 2024-08-07 00:20:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:20:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-08-07 00:20:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:20:07 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-08-07 00:20:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:30 --> No URI present. Default controller set.
DEBUG - 2024-08-07 00:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 00:20:30 --> Total execution time: 0.0339
DEBUG - 2024-08-07 00:20:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:20:32 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-08-07 00:20:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:20:34 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-08-07 00:22:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:22:25 --> No URI present. Default controller set.
DEBUG - 2024-08-07 00:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 00:22:25 --> Total execution time: 0.0354
DEBUG - 2024-08-07 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:22:46 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2024-08-07 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:22:48 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2024-08-07 00:22:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 00:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-07 00:22:52 --> 404 Page Not Found: Configjson/index
DEBUG - 2024-08-07 13:23:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 13:23:39 --> No URI present. Default controller set.
DEBUG - 2024-08-07 13:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 13:23:39 --> Total execution time: 0.0514
DEBUG - 2024-08-07 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 13:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 13:23:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 13:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 13:23:49 --> Total execution time: 0.0674
DEBUG - 2024-08-07 13:23:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 13:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 13:23:54 --> Total execution time: 0.0360
DEBUG - 2024-08-07 15:43:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 15:43:32 --> No URI present. Default controller set.
DEBUG - 2024-08-07 15:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 15:43:32 --> Total execution time: 0.0390
DEBUG - 2024-08-07 15:43:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 15:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 15:43:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 15:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 15:43:36 --> Total execution time: 0.0433
DEBUG - 2024-08-07 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 15:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 15:43:38 --> Total execution time: 0.0390
DEBUG - 2024-08-07 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 15:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 15:43:39 --> Total execution time: 0.0406
DEBUG - 2024-08-07 17:07:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:07:18 --> No URI present. Default controller set.
DEBUG - 2024-08-07 17:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:07:18 --> Total execution time: 0.0407
DEBUG - 2024-08-07 17:07:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:07:24 --> Total execution time: 0.0437
DEBUG - 2024-08-07 17:47:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:47:25 --> Total execution time: 0.0448
DEBUG - 2024-08-07 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:47:31 --> Total execution time: 0.0447
DEBUG - 2024-08-07 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:47:34 --> Total execution time: 0.0434
DEBUG - 2024-08-07 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:58:02 --> Total execution time: 0.0533
DEBUG - 2024-08-07 17:58:04 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:58:04 --> Total execution time: 0.0449
DEBUG - 2024-08-07 17:58:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:58:06 --> Total execution time: 0.0388
DEBUG - 2024-08-07 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 17:58:06 --> Total execution time: 0.0393
DEBUG - 2024-08-07 18:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:04:42 --> Total execution time: 0.0444
DEBUG - 2024-08-07 18:04:50 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:04:50 --> Total execution time: 0.0377
DEBUG - 2024-08-07 18:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:04:53 --> Total execution time: 0.0387
DEBUG - 2024-08-07 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:10 --> Total execution time: 0.0513
DEBUG - 2024-08-07 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:20 --> Total execution time: 0.0425
DEBUG - 2024-08-07 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:23 --> Total execution time: 0.0464
DEBUG - 2024-08-07 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:25 --> Total execution time: 0.0464
DEBUG - 2024-08-07 18:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:05:57 --> Total execution time: 0.0432
DEBUG - 2024-08-07 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-07 18:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-07 18:31:13 --> Total execution time: 0.0431
