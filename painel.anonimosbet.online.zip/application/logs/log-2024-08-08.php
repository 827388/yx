<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-08 00:51:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-08 00:51:39 --> No URI present. Default controller set.
DEBUG - 2024-08-08 00:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-08 00:51:39 --> Total execution time: 0.0442
DEBUG - 2024-08-08 00:51:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-08 00:51:39 --> No URI present. Default controller set.
DEBUG - 2024-08-08 00:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-08 00:51:39 --> Total execution time: 0.0333
DEBUG - 2024-08-08 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-08 06:59:42 --> No URI present. Default controller set.
DEBUG - 2024-08-08 06:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-08 06:59:42 --> Total execution time: 0.0424
DEBUG - 2024-08-08 20:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-08 20:16:15 --> No URI present. Default controller set.
DEBUG - 2024-08-08 20:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-08 20:16:15 --> Total execution time: 0.0526
