<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-09 19:55:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 19:55:17 --> No URI present. Default controller set.
DEBUG - 2024-08-09 19:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-09 19:55:17 --> Total execution time: 0.0461
DEBUG - 2024-08-09 19:55:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 19:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-09 19:55:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 19:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-09 19:55:22 --> Total execution time: 0.0535
DEBUG - 2024-08-09 19:55:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 19:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-09 19:55:28 --> Total execution time: 0.0411
