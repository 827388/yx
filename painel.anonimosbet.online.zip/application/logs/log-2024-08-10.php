<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-10 18:41:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-10 18:41:29 --> No URI present. Default controller set.
DEBUG - 2024-08-10 18:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-10 18:41:29 --> Total execution time: 0.0416
