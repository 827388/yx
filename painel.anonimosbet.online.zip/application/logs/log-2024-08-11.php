<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-11 20:33:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-11 20:33:21 --> No URI present. Default controller set.
DEBUG - 2024-08-11 20:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-11 20:33:21 --> Total execution time: 0.0497
DEBUG - 2024-08-11 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-11 20:33:22 --> No URI present. Default controller set.
DEBUG - 2024-08-11 20:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-11 20:33:22 --> Total execution time: 0.0395
