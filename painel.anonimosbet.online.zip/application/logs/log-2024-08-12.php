<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-12 06:00:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 06:00:42 --> No URI present. Default controller set.
DEBUG - 2024-08-12 06:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 06:00:42 --> Total execution time: 0.0558
DEBUG - 2024-08-12 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 08:52:17 --> No URI present. Default controller set.
DEBUG - 2024-08-12 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 08:52:17 --> Total execution time: 0.0347
DEBUG - 2024-08-12 08:52:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 08:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-12 08:52:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-12 11:43:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 11:43:05 --> No URI present. Default controller set.
DEBUG - 2024-08-12 11:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 11:43:05 --> Total execution time: 0.0472
DEBUG - 2024-08-12 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 11:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-12 11:43:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-12 14:08:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 14:08:08 --> No URI present. Default controller set.
DEBUG - 2024-08-12 14:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 14:08:08 --> Total execution time: 0.0363
DEBUG - 2024-08-12 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 14:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-12 14:08:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-12 17:56:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 17:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 17:56:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 17:56:06 --> No URI present. Default controller set.
DEBUG - 2024-08-12 17:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 17:56:06 --> Total execution time: 0.0426
DEBUG - 2024-08-12 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 22:17:59 --> No URI present. Default controller set.
DEBUG - 2024-08-12 22:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-12 22:17:59 --> Total execution time: 0.0569
DEBUG - 2024-08-12 22:18:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-12 22:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-12 22:18:03 --> 404 Page Not Found: Faviconico/index
