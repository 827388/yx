<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-13 01:35:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-13 01:35:59 --> No URI present. Default controller set.
DEBUG - 2024-08-13 01:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-13 01:35:59 --> Total execution time: 0.0485
DEBUG - 2024-08-13 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-13 01:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-13 01:36:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-13 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-13 07:06:39 --> No URI present. Default controller set.
DEBUG - 2024-08-13 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-13 07:06:39 --> Total execution time: 0.0673
DEBUG - 2024-08-13 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-13 07:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-13 07:06:44 --> 404 Page Not Found: Faviconico/index
