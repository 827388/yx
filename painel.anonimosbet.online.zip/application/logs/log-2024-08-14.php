<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-14 18:13:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:13:21 --> No URI present. Default controller set.
DEBUG - 2024-08-14 18:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:13:21 --> Total execution time: 0.0573
DEBUG - 2024-08-14 18:15:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:15:31 --> No URI present. Default controller set.
DEBUG - 2024-08-14 18:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:15:31 --> Total execution time: 0.0406
DEBUG - 2024-08-14 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:15:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:15:37 --> Total execution time: 0.0439
DEBUG - 2024-08-14 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:15:45 --> No URI present. Default controller set.
DEBUG - 2024-08-14 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:15:45 --> Total execution time: 0.0351
DEBUG - 2024-08-14 18:15:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-14 18:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-14 18:15:54 --> Total execution time: 0.0436
