<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-15 12:58:12 --> UTF-8 Support Enabled
DEBUG - 2024-08-15 12:58:12 --> No URI present. Default controller set.
DEBUG - 2024-08-15 12:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-15 12:58:12 --> Total execution time: 0.0708
DEBUG - 2024-08-15 12:58:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-15 12:58:34 --> No URI present. Default controller set.
DEBUG - 2024-08-15 12:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-15 12:58:34 --> Total execution time: 0.0378
