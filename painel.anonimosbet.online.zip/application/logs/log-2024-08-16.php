<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-16 08:11:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:08 --> No URI present. Default controller set.
DEBUG - 2024-08-16 08:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:11:08 --> Total execution time: 0.0632
DEBUG - 2024-08-16 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:11:15 --> Total execution time: 0.0766
DEBUG - 2024-08-16 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:11:18 --> Total execution time: 0.0529
DEBUG - 2024-08-16 08:11:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:11:20 --> Total execution time: 0.0479
DEBUG - 2024-08-16 08:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-16 08:11:49 --> Query error: Column 'rtpgeral' cannot be null - Invalid query: INSERT INTO `agents` (`email`, `agentCode`, `password`, `token`, `secretKey`, `agentName`, `agentType`, `percent`, `balance`, `depth`, `parentId`, `currency`, `lang`, `createdAt`, `rtpgeral`) VALUES ('saupani@saupani.com', 'saupani', '$2y$10$Kob40Kkqcl6p/IKFjlGsQOrXBH.aAJlZU1sbkIxPTM8.3JMd8r13a', '19acdccae39ca3240e425ffb2098a579', 'c365b7e9c3d3c259a6e40a9651edaffb', 'saupani', 2, 22, 0, 1, '1', 'BRL', 'pt', '2024-08-16 08:11:49', NULL)
DEBUG - 2024-08-16 08:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-16 08:11:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-16 08:12:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:12:02 --> Total execution time: 0.0634
DEBUG - 2024-08-16 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:12:03 --> Total execution time: 0.0461
DEBUG - 2024-08-16 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:12:08 --> Total execution time: 0.0417
DEBUG - 2024-08-16 08:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:14:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:14:18 --> Total execution time: 0.0398
DEBUG - 2024-08-16 08:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:30 --> No URI present. Default controller set.
DEBUG - 2024-08-16 08:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:14:30 --> Total execution time: 0.0375
DEBUG - 2024-08-16 08:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-16 08:14:30 --> 404 Page Not Found: A/index
DEBUG - 2024-08-16 08:14:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:14:45 --> Total execution time: 0.0396
DEBUG - 2024-08-16 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:14:51 --> Total execution time: 0.0346
DEBUG - 2024-08-16 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:15:08 --> Total execution time: 0.0418
DEBUG - 2024-08-16 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:10 --> No URI present. Default controller set.
DEBUG - 2024-08-16 08:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:10 --> Total execution time: 0.0374
DEBUG - 2024-08-16 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:26 --> Total execution time: 0.0407
DEBUG - 2024-08-16 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:35 --> Total execution time: 0.0357
DEBUG - 2024-08-16 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:47 --> Total execution time: 0.0426
DEBUG - 2024-08-16 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:56:59 --> Total execution time: 0.0424
DEBUG - 2024-08-16 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 08:57:01 --> Total execution time: 0.0467
DEBUG - 2024-08-16 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-16 14:45:41 --> No URI present. Default controller set.
DEBUG - 2024-08-16 14:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 14:45:41 --> Total execution time: 0.0511
