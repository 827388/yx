<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-17 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 12:35:40 --> No URI present. Default controller set.
DEBUG - 2024-08-17 12:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 12:35:40 --> Total execution time: 0.0590
DEBUG - 2024-08-17 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 12:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 12:35:48 --> Total execution time: 0.0558
DEBUG - 2024-08-17 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 12:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 12:35:51 --> Total execution time: 0.0389
DEBUG - 2024-08-17 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 14:41:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-17 14:41:54 --> No URI present. Default controller set.
DEBUG - 2024-08-17 14:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-17 14:41:54 --> Total execution time: 0.0393
