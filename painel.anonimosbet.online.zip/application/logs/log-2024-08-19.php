<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-19 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-19 14:25:24 --> No URI present. Default controller set.
DEBUG - 2024-08-19 14:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-19 14:25:24 --> Total execution time: 0.0831
DEBUG - 2024-08-19 14:25:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-19 14:25:27 --> No URI present. Default controller set.
DEBUG - 2024-08-19 14:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-19 14:25:27 --> Total execution time: 0.0351
DEBUG - 2024-08-19 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-19 14:26:30 --> No URI present. Default controller set.
DEBUG - 2024-08-19 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-19 14:26:30 --> Total execution time: 0.0426
DEBUG - 2024-08-19 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-19 14:26:33 --> No URI present. Default controller set.
DEBUG - 2024-08-19 14:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-19 14:26:33 --> Total execution time: 0.0380
