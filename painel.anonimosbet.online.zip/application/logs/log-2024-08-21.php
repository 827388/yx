<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-21 00:39:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 00:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 00:39:26 --> Total execution time: 0.0208
DEBUG - 2024-08-21 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 06:16:39 --> No URI present. Default controller set.
DEBUG - 2024-08-21 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 06:16:39 --> Total execution time: 0.0178
DEBUG - 2024-08-21 09:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 09:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 09:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 09:31:11 --> No URI present. Default controller set.
DEBUG - 2024-08-21 09:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 09:31:11 --> Total execution time: 0.0147
DEBUG - 2024-08-21 11:38:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 11:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 11:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 11:38:44 --> Total execution time: 0.0163
DEBUG - 2024-08-21 20:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:29:15 --> No URI present. Default controller set.
DEBUG - 2024-08-21 20:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:29:15 --> Total execution time: 0.0168
DEBUG - 2024-08-21 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:22 --> No URI present. Default controller set.
DEBUG - 2024-08-21 20:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:22 --> Total execution time: 0.0155
DEBUG - 2024-08-21 20:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:26 --> Total execution time: 0.0162
DEBUG - 2024-08-21 20:33:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:32 --> No URI present. Default controller set.
DEBUG - 2024-08-21 20:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:32 --> Total execution time: 0.0143
DEBUG - 2024-08-21 20:33:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:39 --> Total execution time: 0.0161
DEBUG - 2024-08-21 20:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:43 --> No URI present. Default controller set.
DEBUG - 2024-08-21 20:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:43 --> Total execution time: 0.0149
DEBUG - 2024-08-21 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:51 --> Total execution time: 0.0171
DEBUG - 2024-08-21 20:33:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:33:57 --> Total execution time: 0.0152
DEBUG - 2024-08-21 20:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:05 --> Total execution time: 0.0172
DEBUG - 2024-08-21 20:34:12 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:13 --> No URI present. Default controller set.
DEBUG - 2024-08-21 20:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:13 --> Total execution time: 0.0148
DEBUG - 2024-08-21 20:34:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:19 --> Total execution time: 0.0176
DEBUG - 2024-08-21 20:34:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:21 --> Total execution time: 0.0171
DEBUG - 2024-08-21 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:28 --> Total execution time: 0.0181
DEBUG - 2024-08-21 20:34:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:30 --> Total execution time: 0.0162
DEBUG - 2024-08-21 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:34:34 --> Total execution time: 0.0167
DEBUG - 2024-08-21 20:53:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-21 20:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-21 20:53:15 --> Total execution time: 0.0187
