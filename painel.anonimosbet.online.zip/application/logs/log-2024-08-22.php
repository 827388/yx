<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-22 14:23:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:23:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:23:44 --> No URI present. Default controller set.
DEBUG - 2024-08-22 14:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:23:44 --> Total execution time: 0.0156
DEBUG - 2024-08-22 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:45:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:45:01 --> Total execution time: 0.0173
DEBUG - 2024-08-22 14:45:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:45:02 --> Total execution time: 0.0165
DEBUG - 2024-08-22 14:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:45:32 --> Total execution time: 0.0152
DEBUG - 2024-08-22 14:50:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:50:45 --> Total execution time: 0.0240
DEBUG - 2024-08-22 14:50:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:50:45 --> Total execution time: 0.0174
DEBUG - 2024-08-22 14:50:50 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:50:50 --> Total execution time: 0.0170
DEBUG - 2024-08-22 14:51:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:05 --> Total execution time: 0.0186
DEBUG - 2024-08-22 14:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:10 --> Total execution time: 0.0172
DEBUG - 2024-08-22 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:12 --> Total execution time: 0.0179
DEBUG - 2024-08-22 14:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:13 --> Total execution time: 0.0158
DEBUG - 2024-08-22 14:51:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:15 --> Total execution time: 0.0179
DEBUG - 2024-08-22 14:51:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:25 --> Total execution time: 0.0162
DEBUG - 2024-08-22 14:51:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:28 --> Total execution time: 0.0154
DEBUG - 2024-08-22 14:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:32 --> Total execution time: 0.0170
DEBUG - 2024-08-22 14:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:33 --> Total execution time: 0.0156
DEBUG - 2024-08-22 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:51:35 --> Total execution time: 0.0158
DEBUG - 2024-08-22 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:52:35 --> Total execution time: 0.0167
DEBUG - 2024-08-22 14:52:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:52:39 --> Total execution time: 0.0185
DEBUG - 2024-08-22 14:53:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:08 --> Total execution time: 0.0201
DEBUG - 2024-08-22 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:10 --> Total execution time: 0.0171
DEBUG - 2024-08-22 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:11 --> Total execution time: 0.0161
DEBUG - 2024-08-22 14:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:12 --> Total execution time: 0.0158
DEBUG - 2024-08-22 14:53:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:13 --> Total execution time: 0.0154
DEBUG - 2024-08-22 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:15 --> Total execution time: 0.0172
DEBUG - 2024-08-22 14:53:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:53:34 --> Total execution time: 0.0171
DEBUG - 2024-08-22 14:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:54:29 --> Total execution time: 0.0176
DEBUG - 2024-08-22 14:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:57:01 --> Total execution time: 0.0172
DEBUG - 2024-08-22 14:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 14:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 14:59:39 --> Total execution time: 0.0203
DEBUG - 2024-08-22 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:20:08 --> Total execution time: 0.0174
DEBUG - 2024-08-22 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:37:37 --> No URI present. Default controller set.
DEBUG - 2024-08-22 15:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:37:37 --> Total execution time: 0.0166
DEBUG - 2024-08-22 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:54:39 --> Total execution time: 0.0189
DEBUG - 2024-08-22 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:54:40 --> Total execution time: 0.0191
DEBUG - 2024-08-22 15:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:55:33 --> No URI present. Default controller set.
DEBUG - 2024-08-22 15:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:55:33 --> Total execution time: 0.0152
DEBUG - 2024-08-22 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:55:37 --> Total execution time: 0.0169
DEBUG - 2024-08-22 15:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:55:38 --> Total execution time: 0.0162
DEBUG - 2024-08-22 15:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:56:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:56:49 --> No URI present. Default controller set.
DEBUG - 2024-08-22 15:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:56:49 --> Total execution time: 0.0153
DEBUG - 2024-08-22 15:56:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:56:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:56:53 --> Total execution time: 0.0170
DEBUG - 2024-08-22 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:56:55 --> Total execution time: 0.0164
DEBUG - 2024-08-22 15:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 15:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 15:57:01 --> Total execution time: 0.0158
DEBUG - 2024-08-22 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:04:02 --> Total execution time: 0.0236
DEBUG - 2024-08-22 16:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:06:48 --> Total execution time: 0.0176
DEBUG - 2024-08-22 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:07:26 --> Total execution time: 0.0158
DEBUG - 2024-08-22 16:07:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:07:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:07:29 --> Total execution time: 0.0158
DEBUG - 2024-08-22 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:11:19 --> Total execution time: 0.0178
DEBUG - 2024-08-22 16:11:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:11:28 --> Total execution time: 0.0167
DEBUG - 2024-08-22 16:12:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:22 --> Total execution time: 0.0187
DEBUG - 2024-08-22 16:12:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:26 --> Total execution time: 0.0179
DEBUG - 2024-08-22 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:27 --> Total execution time: 0.0183
DEBUG - 2024-08-22 16:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:30 --> Total execution time: 0.0164
DEBUG - 2024-08-22 16:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:31 --> Total execution time: 0.0158
DEBUG - 2024-08-22 16:12:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:33 --> Total execution time: 0.0178
DEBUG - 2024-08-22 16:12:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:37 --> Total execution time: 0.0194
DEBUG - 2024-08-22 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:46 --> Total execution time: 0.0162
DEBUG - 2024-08-22 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:47 --> Total execution time: 0.0164
DEBUG - 2024-08-22 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:12:58 --> Total execution time: 0.0167
DEBUG - 2024-08-22 16:13:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:13:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:13:44 --> Total execution time: 0.0153
DEBUG - 2024-08-22 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:13:48 --> Total execution time: 0.0162
DEBUG - 2024-08-22 16:13:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 16:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 16:13:51 --> Total execution time: 0.0161
DEBUG - 2024-08-22 19:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:34:15 --> No URI present. Default controller set.
DEBUG - 2024-08-22 19:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:34:15 --> Total execution time: 0.0209
DEBUG - 2024-08-22 19:34:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:34:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:34:19 --> Total execution time: 0.0177
DEBUG - 2024-08-22 19:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:34:25 --> Total execution time: 0.0182
DEBUG - 2024-08-22 19:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:50:28 --> No URI present. Default controller set.
DEBUG - 2024-08-22 19:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:50:28 --> Total execution time: 0.0164
DEBUG - 2024-08-22 19:50:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:50:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:50:31 --> Total execution time: 0.0165
DEBUG - 2024-08-22 19:50:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 19:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 19:50:33 --> Total execution time: 0.0179
DEBUG - 2024-08-22 21:09:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 21:09:54 --> No URI present. Default controller set.
DEBUG - 2024-08-22 21:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 21:09:54 --> Total execution time: 0.0166
DEBUG - 2024-08-22 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 21:37:21 --> No URI present. Default controller set.
DEBUG - 2024-08-22 21:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 21:37:21 --> Total execution time: 0.0158
DEBUG - 2024-08-22 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 21:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 21:52:06 --> No URI present. Default controller set.
DEBUG - 2024-08-22 21:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 21:52:06 --> Total execution time: 0.0148
DEBUG - 2024-08-22 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:13:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:13:42 --> Total execution time: 0.0162
DEBUG - 2024-08-22 22:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:13:43 --> Total execution time: 0.0188
DEBUG - 2024-08-22 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:17 --> Total execution time: 0.0164
DEBUG - 2024-08-22 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:27 --> Total execution time: 0.0172
DEBUG - 2024-08-22 22:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:41 --> Total execution time: 0.0179
DEBUG - 2024-08-22 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:48 --> Total execution time: 0.0158
DEBUG - 2024-08-22 22:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:14:51 --> No URI present. Default controller set.
DEBUG - 2024-08-22 22:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:14:51 --> Total execution time: 0.0155
DEBUG - 2024-08-22 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:00 --> Total execution time: 0.0143
DEBUG - 2024-08-22 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:15 --> Total execution time: 0.0165
DEBUG - 2024-08-22 22:15:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:18 --> Total execution time: 0.0162
DEBUG - 2024-08-22 22:15:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:41 --> Total execution time: 0.0155
DEBUG - 2024-08-22 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:46 --> No URI present. Default controller set.
DEBUG - 2024-08-22 22:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:46 --> Total execution time: 0.0160
DEBUG - 2024-08-22 22:15:50 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:51 --> Total execution time: 0.0160
DEBUG - 2024-08-22 22:15:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:15:52 --> Total execution time: 0.0153
DEBUG - 2024-08-22 22:16:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:11 --> No URI present. Default controller set.
DEBUG - 2024-08-22 22:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:11 --> Total execution time: 0.0149
DEBUG - 2024-08-22 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:16 --> Total execution time: 0.0165
DEBUG - 2024-08-22 22:16:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:17 --> Total execution time: 0.0161
DEBUG - 2024-08-22 22:16:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:27 --> Total execution time: 0.0146
DEBUG - 2024-08-22 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:16:29 --> Total execution time: 0.0155
DEBUG - 2024-08-22 22:17:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:17:43 --> Total execution time: 0.0173
DEBUG - 2024-08-22 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:26:35 --> Total execution time: 0.0159
DEBUG - 2024-08-22 22:27:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:27:38 --> Total execution time: 0.0176
DEBUG - 2024-08-22 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:30:13 --> Total execution time: 0.0172
DEBUG - 2024-08-22 22:31:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:31:43 --> Total execution time: 0.0182
DEBUG - 2024-08-22 22:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:32:31 --> Total execution time: 0.0177
DEBUG - 2024-08-22 22:32:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:32:33 --> Total execution time: 0.0161
DEBUG - 2024-08-22 22:32:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:32:34 --> Total execution time: 0.0162
DEBUG - 2024-08-22 22:32:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 22:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 22:32:35 --> Total execution time: 0.0184
DEBUG - 2024-08-22 23:23:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:23:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:23:14 --> Total execution time: 0.0150
DEBUG - 2024-08-22 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:40 --> Total execution time: 0.0153
DEBUG - 2024-08-22 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:45 --> Total execution time: 0.0151
DEBUG - 2024-08-22 23:28:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:47 --> Total execution time: 0.0150
DEBUG - 2024-08-22 23:28:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:28:56 --> Total execution time: 0.0155
DEBUG - 2024-08-22 23:29:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:29:13 --> Total execution time: 0.0155
DEBUG - 2024-08-22 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:29:49 --> Total execution time: 0.0161
DEBUG - 2024-08-22 23:30:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:30:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:30:46 --> Total execution time: 0.0142
DEBUG - 2024-08-22 23:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:36:42 --> Total execution time: 0.0187
DEBUG - 2024-08-22 23:36:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:36:45 --> Total execution time: 0.0208
DEBUG - 2024-08-22 23:36:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:36:47 --> Total execution time: 0.0168
DEBUG - 2024-08-22 23:36:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:36:48 --> Total execution time: 0.0143
DEBUG - 2024-08-22 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:38:55 --> Total execution time: 0.0167
DEBUG - 2024-08-22 23:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:45:27 --> Total execution time: 0.0390
DEBUG - 2024-08-22 23:45:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-22 23:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-22 23:45:29 --> Total execution time: 0.0166
