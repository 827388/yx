<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-23 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:01 --> Total execution time: 0.0184
DEBUG - 2024-08-23 01:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:03 --> No URI present. Default controller set.
DEBUG - 2024-08-23 01:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:03 --> Total execution time: 0.0151
DEBUG - 2024-08-23 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:08 --> Total execution time: 0.0161
DEBUG - 2024-08-23 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:11 --> Total execution time: 0.0169
DEBUG - 2024-08-23 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 01:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 01:01:15 --> Total execution time: 0.0159
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> No URI present. Default controller set.
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 09:40:14 --> Total execution time: 0.0204
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> No URI present. Default controller set.
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 09:40:14 --> Total execution time: 0.0167
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-23 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-08-23 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:15 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-08-23 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 09:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 09:40:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-08-23 10:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 10:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 10:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 10:18:10 --> No URI present. Default controller set.
DEBUG - 2024-08-23 10:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 10:18:10 --> Total execution time: 0.0176
DEBUG - 2024-08-23 10:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 10:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 10:18:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 10:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 10:18:13 --> Total execution time: 0.0175
DEBUG - 2024-08-23 10:18:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 10:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 10:18:14 --> Total execution time: 0.0168
DEBUG - 2024-08-23 16:48:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 16:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 16:48:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 16:48:58 --> No URI present. Default controller set.
DEBUG - 2024-08-23 16:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 16:48:58 --> Total execution time: 0.0151
DEBUG - 2024-08-23 16:49:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 16:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 16:49:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 16:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 16:49:02 --> Total execution time: 0.0167
DEBUG - 2024-08-23 16:53:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 16:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 16:53:56 --> Total execution time: 0.0179
DEBUG - 2024-08-23 17:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 17:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 17:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 17:01:03 --> No URI present. Default controller set.
DEBUG - 2024-08-23 17:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 17:01:03 --> Total execution time: 0.0158
DEBUG - 2024-08-23 17:01:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 17:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 17:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 17:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 17:01:59 --> Total execution time: 0.0159
DEBUG - 2024-08-23 17:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 17:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 17:02:14 --> Total execution time: 0.0187
DEBUG - 2024-08-23 18:30:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 18:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 18:30:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 18:30:16 --> No URI present. Default controller set.
DEBUG - 2024-08-23 18:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 18:30:16 --> Total execution time: 0.0148
DEBUG - 2024-08-23 20:43:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 20:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-23 20:43:56 --> 404 Page Not Found: Env/index
DEBUG - 2024-08-23 21:40:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 21:40:51 --> No URI present. Default controller set.
DEBUG - 2024-08-23 21:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 21:40:51 --> Total execution time: 0.0173
DEBUG - 2024-08-23 21:42:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 21:42:35 --> No URI present. Default controller set.
DEBUG - 2024-08-23 21:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 21:42:35 --> Total execution time: 0.0163
DEBUG - 2024-08-23 21:43:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-23 21:43:43 --> No URI present. Default controller set.
DEBUG - 2024-08-23 21:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-23 21:43:43 --> Total execution time: 0.0166
