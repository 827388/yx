<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-24 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 09:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 09:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 09:45:21 --> Total execution time: 0.0187
DEBUG - 2024-08-24 09:45:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 09:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 09:45:22 --> Total execution time: 0.0166
DEBUG - 2024-08-24 10:52:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 10:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 10:52:33 --> Total execution time: 0.0179
DEBUG - 2024-08-24 14:26:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 14:26:07 --> No URI present. Default controller set.
DEBUG - 2024-08-24 14:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 14:26:07 --> Total execution time: 0.0165
DEBUG - 2024-08-24 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 14:33:19 --> No URI present. Default controller set.
DEBUG - 2024-08-24 14:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 14:33:19 --> Total execution time: 0.0153
DEBUG - 2024-08-24 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 14:39:44 --> No URI present. Default controller set.
DEBUG - 2024-08-24 14:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 14:39:44 --> Total execution time: 0.0171
DEBUG - 2024-08-24 15:59:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 15:59:36 --> No URI present. Default controller set.
DEBUG - 2024-08-24 15:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 15:59:36 --> Total execution time: 0.0165
DEBUG - 2024-08-24 19:01:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 19:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 19:01:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 19:01:56 --> No URI present. Default controller set.
DEBUG - 2024-08-24 19:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 19:01:56 --> Total execution time: 0.0157
DEBUG - 2024-08-24 19:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 19:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 19:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 19:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 19:02:00 --> Total execution time: 0.0204
DEBUG - 2024-08-24 22:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:22:15 --> No URI present. Default controller set.
DEBUG - 2024-08-24 22:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:22:15 --> Total execution time: 0.0149
DEBUG - 2024-08-24 22:52:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:52:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:52:29 --> No URI present. Default controller set.
DEBUG - 2024-08-24 22:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:52:29 --> Total execution time: 0.0144
DEBUG - 2024-08-24 22:52:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:52:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:52:35 --> Total execution time: 0.0177
DEBUG - 2024-08-24 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:52:37 --> Total execution time: 0.0190
DEBUG - 2024-08-24 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:53:37 --> Total execution time: 0.0165
DEBUG - 2024-08-24 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:29 --> No URI present. Default controller set.
DEBUG - 2024-08-24 22:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:29 --> Total execution time: 0.0156
DEBUG - 2024-08-24 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:33 --> Total execution time: 0.0183
DEBUG - 2024-08-24 22:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:34 --> Total execution time: 0.0166
DEBUG - 2024-08-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:43 --> No URI present. Default controller set.
DEBUG - 2024-08-24 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:43 --> Total execution time: 0.0199
DEBUG - 2024-08-24 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:47 --> Total execution time: 0.0169
DEBUG - 2024-08-24 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:48 --> Total execution time: 0.0165
DEBUG - 2024-08-24 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:54:53 --> Total execution time: 0.0174
DEBUG - 2024-08-24 22:55:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:55:59 --> Total execution time: 0.0172
DEBUG - 2024-08-24 22:56:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:56:00 --> Total execution time: 0.0172
DEBUG - 2024-08-24 22:56:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:56:05 --> Total execution time: 0.0165
DEBUG - 2024-08-24 22:56:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:56:07 --> Total execution time: 0.0178
DEBUG - 2024-08-24 22:56:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:56:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 22:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 22:56:14 --> Total execution time: 0.0160
DEBUG - 2024-08-24 23:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:02:20 --> Total execution time: 0.0161
DEBUG - 2024-08-24 23:10:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:31 --> Total execution time: 0.0190
DEBUG - 2024-08-24 23:10:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:36 --> Total execution time: 0.0170
DEBUG - 2024-08-24 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:42 --> Total execution time: 0.0182
DEBUG - 2024-08-24 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:48 --> Total execution time: 0.0169
DEBUG - 2024-08-24 23:10:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:51 --> Total execution time: 0.0175
DEBUG - 2024-08-24 23:10:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:52 --> Total execution time: 0.0161
DEBUG - 2024-08-24 23:10:55 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:55 --> Total execution time: 0.0165
DEBUG - 2024-08-24 23:10:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:56 --> Total execution time: 0.0158
DEBUG - 2024-08-24 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:57 --> Total execution time: 0.0187
DEBUG - 2024-08-24 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:58 --> Total execution time: 0.0162
DEBUG - 2024-08-24 23:10:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:10:59 --> Total execution time: 0.0173
DEBUG - 2024-08-24 23:11:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-24 23:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-24 23:11:09 --> Total execution time: 0.0161
