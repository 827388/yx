<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-25 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:25 --> No URI present. Default controller set.
DEBUG - 2024-08-25 20:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:25 --> Total execution time: 0.0162
DEBUG - 2024-08-25 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:30 --> Total execution time: 0.0176
DEBUG - 2024-08-25 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:31 --> Total execution time: 0.0169
DEBUG - 2024-08-25 20:19:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:32 --> Total execution time: 0.0168
DEBUG - 2024-08-25 20:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 20:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 20:19:39 --> Total execution time: 0.0162
DEBUG - 2024-08-25 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:03 --> No URI present. Default controller set.
DEBUG - 2024-08-25 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:03 --> Total execution time: 0.0195
DEBUG - 2024-08-25 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:14 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:14 --> Total execution time: 0.0171
DEBUG - 2024-08-25 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:19 --> Total execution time: 0.0162
DEBUG - 2024-08-25 21:00:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:22 --> Total execution time: 0.0166
DEBUG - 2024-08-25 21:00:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:47 --> Total execution time: 0.0160
DEBUG - 2024-08-25 21:00:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:00:53 --> Total execution time: 0.0183
DEBUG - 2024-08-25 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:00 --> Total execution time: 0.0210
DEBUG - 2024-08-25 21:01:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:06 --> Total execution time: 0.0166
DEBUG - 2024-08-25 21:01:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:08 --> Total execution time: 0.0167
DEBUG - 2024-08-25 21:01:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:18 --> No URI present. Default controller set.
DEBUG - 2024-08-25 21:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:18 --> Total execution time: 0.0146
DEBUG - 2024-08-25 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:28 --> Total execution time: 0.0164
DEBUG - 2024-08-25 21:01:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:32 --> Total execution time: 0.0170
DEBUG - 2024-08-25 21:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:52 --> Total execution time: 0.0169
DEBUG - 2024-08-25 21:01:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:01:57 --> Total execution time: 0.0162
DEBUG - 2024-08-25 21:02:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:02 --> No URI present. Default controller set.
DEBUG - 2024-08-25 21:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:02 --> Total execution time: 0.0156
DEBUG - 2024-08-25 21:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:06 --> Total execution time: 0.0207
DEBUG - 2024-08-25 21:02:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:08 --> Total execution time: 0.0178
DEBUG - 2024-08-25 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:29 --> No URI present. Default controller set.
DEBUG - 2024-08-25 21:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:29 --> Total execution time: 0.0155
DEBUG - 2024-08-25 21:02:34 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:37 --> Total execution time: 0.0165
DEBUG - 2024-08-25 21:02:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:40 --> Total execution time: 0.0173
DEBUG - 2024-08-25 21:02:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-25 21:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-25 21:02:57 --> Total execution time: 0.0164
