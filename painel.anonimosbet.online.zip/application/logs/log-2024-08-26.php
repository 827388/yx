<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-26 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 12:16:48 --> No URI present. Default controller set.
DEBUG - 2024-08-26 12:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 12:16:48 --> Total execution time: 0.0169
DEBUG - 2024-08-26 14:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 14:26:16 --> No URI present. Default controller set.
DEBUG - 2024-08-26 14:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 14:26:16 --> Total execution time: 0.0169
DEBUG - 2024-08-26 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:59:56 --> No URI present. Default controller set.
DEBUG - 2024-08-26 15:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 15:59:56 --> Total execution time: 0.0208
DEBUG - 2024-08-26 16:38:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 16:38:20 --> No URI present. Default controller set.
DEBUG - 2024-08-26 16:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 16:38:20 --> Total execution time: 0.0184
DEBUG - 2024-08-26 20:24:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 20:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 20:24:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 20:24:48 --> No URI present. Default controller set.
DEBUG - 2024-08-26 20:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 20:24:48 --> Total execution time: 0.0162
DEBUG - 2024-08-26 20:24:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 20:24:53 --> No URI present. Default controller set.
DEBUG - 2024-08-26 20:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 20:24:53 --> Total execution time: 0.0161
DEBUG - 2024-08-26 20:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 20:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 20:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 20:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 20:24:59 --> Total execution time: 0.0165
DEBUG - 2024-08-26 21:17:20 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 21:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 21:17:20 --> Total execution time: 0.0192
DEBUG - 2024-08-26 21:17:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 21:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 21:17:22 --> Total execution time: 0.0172
DEBUG - 2024-08-26 22:14:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 22:14:58 --> No URI present. Default controller set.
DEBUG - 2024-08-26 22:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 22:14:58 --> Total execution time: 0.0176
