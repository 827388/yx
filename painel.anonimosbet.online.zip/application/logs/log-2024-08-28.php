<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-28 02:19:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:16 --> Total execution time: 0.0169
DEBUG - 2024-08-28 02:19:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:43 --> Total execution time: 0.0164
DEBUG - 2024-08-28 02:19:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:49 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:19:49 --> Total execution time: 0.0167
DEBUG - 2024-08-28 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:20:40 --> Total execution time: 0.0196
DEBUG - 2024-08-28 02:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:21:16 --> Total execution time: 0.0157
DEBUG - 2024-08-28 02:22:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:22:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:22:37 --> Total execution time: 0.0151
DEBUG - 2024-08-28 02:22:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:22:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:22:40 --> Total execution time: 0.0166
DEBUG - 2024-08-28 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:26:35 --> Total execution time: 0.0159
DEBUG - 2024-08-28 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:26:38 --> No URI present. Default controller set.
DEBUG - 2024-08-28 02:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:26:38 --> Total execution time: 0.0159
DEBUG - 2024-08-28 02:26:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:26:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:26:53 --> Total execution time: 0.0166
DEBUG - 2024-08-28 02:27:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:27:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:27:01 --> Total execution time: 0.0164
DEBUG - 2024-08-28 02:28:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:28:22 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:28:22 --> Total execution time: 0.0156
DEBUG - 2024-08-28 02:28:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:28:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:28:43 --> Total execution time: 0.0159
DEBUG - 2024-08-28 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:29:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:29:24 --> Total execution time: 0.0169
DEBUG - 2024-08-28 02:30:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:30:36 --> Total execution time: 0.0170
DEBUG - 2024-08-28 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 02:30:47 --> Total execution time: 0.0159
DEBUG - 2024-08-28 05:51:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 05:51:47 --> No URI present. Default controller set.
DEBUG - 2024-08-28 05:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 05:51:47 --> Total execution time: 0.0176
DEBUG - 2024-08-28 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 09:04:54 --> No URI present. Default controller set.
DEBUG - 2024-08-28 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 09:04:54 --> Total execution time: 0.0172
DEBUG - 2024-08-28 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 09:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 09:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 09:04:59 --> Total execution time: 0.0194
DEBUG - 2024-08-28 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 09:05:01 --> Total execution time: 0.0194
DEBUG - 2024-08-28 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 10:14:41 --> Total execution time: 0.0202
DEBUG - 2024-08-28 11:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-28 11:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-28 11:09:58 --> Total execution time: 0.0206
