<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-29 17:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-29 17:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-29 17:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-29 17:40:56 --> No URI present. Default controller set.
DEBUG - 2024-08-29 17:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-29 17:40:56 --> Total execution time: 0.0176
DEBUG - 2024-08-29 18:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-29 18:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-29 18:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-29 18:06:13 --> No URI present. Default controller set.
DEBUG - 2024-08-29 18:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-29 18:06:13 --> Total execution time: 0.0173
