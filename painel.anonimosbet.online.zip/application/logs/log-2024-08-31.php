<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-08-31 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:15:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:15:57 --> Total execution time: 0.0234
DEBUG - 2024-08-31 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-31 12:15:58 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-08-31 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-08-31 12:15:58 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-08-31 12:16:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:16:32 --> Total execution time: 0.0207
DEBUG - 2024-08-31 12:16:41 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:16:41 --> Total execution time: 0.0227
DEBUG - 2024-08-31 12:16:47 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:16:47 --> Total execution time: 0.0197
DEBUG - 2024-08-31 12:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 12:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 12:17:29 --> Total execution time: 0.0234
DEBUG - 2024-08-31 16:44:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 16:44:58 --> No URI present. Default controller set.
DEBUG - 2024-08-31 16:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 16:44:58 --> Total execution time: 0.0202
DEBUG - 2024-08-31 16:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 16:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 16:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 16:45:09 --> No URI present. Default controller set.
DEBUG - 2024-08-31 16:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 16:45:09 --> Total execution time: 0.0236
DEBUG - 2024-08-31 19:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:09 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:09 --> Total execution time: 0.0193
DEBUG - 2024-08-31 19:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:13 --> Total execution time: 0.0195
DEBUG - 2024-08-31 19:56:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:18 --> Total execution time: 0.0244
DEBUG - 2024-08-31 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:56:46 --> Total execution time: 0.0183
DEBUG - 2024-08-31 19:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:11 --> Total execution time: 0.0178
DEBUG - 2024-08-31 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:19 --> Total execution time: 0.0199
DEBUG - 2024-08-31 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:27 --> Total execution time: 0.0197
DEBUG - 2024-08-31 19:57:38 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:38 --> Total execution time: 0.0195
DEBUG - 2024-08-31 19:57:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:40 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:40 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:40 --> Total execution time: 0.0184
DEBUG - 2024-08-31 19:57:50 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:51 --> Total execution time: 0.0196
DEBUG - 2024-08-31 19:57:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:57 --> Total execution time: 0.0221
DEBUG - 2024-08-31 19:57:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:58 --> Total execution time: 0.0187
DEBUG - 2024-08-31 19:57:59 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:57:59 --> Total execution time: 0.0204
DEBUG - 2024-08-31 19:58:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:00 --> Total execution time: 0.0177
DEBUG - 2024-08-31 19:58:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:01 --> Total execution time: 0.0225
DEBUG - 2024-08-31 19:58:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:03 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:03 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:03 --> Total execution time: 0.0174
DEBUG - 2024-08-31 19:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:07 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:07 --> Total execution time: 0.0179
DEBUG - 2024-08-31 19:58:08 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:08 --> Total execution time: 0.0204
DEBUG - 2024-08-31 19:58:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:18 --> Total execution time: 0.0192
DEBUG - 2024-08-31 19:58:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:24 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:24 --> Total execution time: 0.0198
DEBUG - 2024-08-31 19:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:26 --> Total execution time: 0.0211
DEBUG - 2024-08-31 19:58:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:30 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:30 --> Total execution time: 0.0186
DEBUG - 2024-08-31 19:58:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:39 --> Total execution time: 0.0197
DEBUG - 2024-08-31 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:42 --> Total execution time: 0.0173
DEBUG - 2024-08-31 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:58:43 --> Total execution time: 0.0207
DEBUG - 2024-08-31 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:15 --> Total execution time: 0.0192
DEBUG - 2024-08-31 19:59:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:17 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:17 --> Total execution time: 0.0154
DEBUG - 2024-08-31 19:59:23 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:26 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:26 --> Total execution time: 0.0217
DEBUG - 2024-08-31 19:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:28 --> Total execution time: 0.0199
DEBUG - 2024-08-31 19:59:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:37 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:37 --> No URI present. Default controller set.
DEBUG - 2024-08-31 19:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:37 --> Total execution time: 0.0189
DEBUG - 2024-08-31 19:59:45 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:46 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:46 --> Total execution time: 0.0189
DEBUG - 2024-08-31 19:59:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:48 --> Total execution time: 0.0187
DEBUG - 2024-08-31 19:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-08-31 19:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-31 19:59:53 --> Total execution time: 0.0178
