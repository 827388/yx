<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-03 17:53:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-03 17:53:23 --> No URI present. Default controller set.
DEBUG - 2024-09-03 17:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-03 17:53:23 --> Total execution time: 0.0410
DEBUG - 2024-09-03 20:00:55 --> UTF-8 Support Enabled
DEBUG - 2024-09-03 20:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-03 20:00:55 --> UTF-8 Support Enabled
DEBUG - 2024-09-03 20:00:55 --> No URI present. Default controller set.
DEBUG - 2024-09-03 20:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-03 20:00:55 --> Total execution time: 0.0168
