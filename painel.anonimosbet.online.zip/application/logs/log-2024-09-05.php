<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-05 14:44:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:44:46 --> Total execution time: 0.0222
DEBUG - 2024-09-05 14:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:44:47 --> Total execution time: 0.0232
DEBUG - 2024-09-05 14:58:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:58:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:58:06 --> Total execution time: 0.0222
DEBUG - 2024-09-05 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:58:08 --> Total execution time: 0.0215
DEBUG - 2024-09-05 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 14:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 14:58:15 --> Total execution time: 0.0242
DEBUG - 2024-09-05 15:00:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:00:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:00:13 --> Total execution time: 0.0208
DEBUG - 2024-09-05 15:04:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:07 --> Total execution time: 0.0221
DEBUG - 2024-09-05 15:04:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:30 --> Total execution time: 0.0224
DEBUG - 2024-09-05 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:53 --> Total execution time: 0.0223
DEBUG - 2024-09-05 15:04:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:04:54 --> Total execution time: 0.0214
DEBUG - 2024-09-05 15:50:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 15:50:37 --> No URI present. Default controller set.
DEBUG - 2024-09-05 15:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 15:50:37 --> Total execution time: 0.0231
DEBUG - 2024-09-05 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:25:44 --> Total execution time: 0.0320
DEBUG - 2024-09-05 21:25:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-05 21:25:45 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-09-05 21:25:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-05 21:25:45 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-09-05 21:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:25:54 --> Total execution time: 0.0268
DEBUG - 2024-09-05 21:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:32 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:32 --> Total execution time: 0.0258
DEBUG - 2024-09-05 21:26:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:36 --> Total execution time: 0.0232
DEBUG - 2024-09-05 21:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:42 --> Total execution time: 0.0244
DEBUG - 2024-09-05 21:26:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:45 --> Total execution time: 0.0217
DEBUG - 2024-09-05 21:26:49 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:49 --> Total execution time: 0.0254
DEBUG - 2024-09-05 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:26:57 --> No URI present. Default controller set.
DEBUG - 2024-09-05 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:26:57 --> Total execution time: 0.0205
DEBUG - 2024-09-05 21:27:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:27:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:27:12 --> Total execution time: 0.0271
DEBUG - 2024-09-05 21:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:27:14 --> Total execution time: 0.0216
DEBUG - 2024-09-05 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-05 21:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-05 21:27:41 --> Total execution time: 0.0218
