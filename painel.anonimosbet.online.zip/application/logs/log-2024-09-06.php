<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-06 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-06 04:23:05 --> No URI present. Default controller set.
DEBUG - 2024-09-06 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-06 04:23:05 --> Total execution time: 0.0280
DEBUG - 2024-09-06 06:54:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-06 06:54:45 --> No URI present. Default controller set.
DEBUG - 2024-09-06 06:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-06 06:54:45 --> Total execution time: 0.0219
DEBUG - 2024-09-06 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-06 11:17:43 --> No URI present. Default controller set.
DEBUG - 2024-09-06 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-06 11:17:43 --> Total execution time: 0.0348
