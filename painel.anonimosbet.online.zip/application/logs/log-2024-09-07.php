<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-07 15:35:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 15:35:57 --> No URI present. Default controller set.
DEBUG - 2024-09-07 15:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 15:35:57 --> Total execution time: 0.0382
DEBUG - 2024-09-07 17:33:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:06 --> No URI present. Default controller set.
DEBUG - 2024-09-07 17:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:06 --> Total execution time: 0.0217
DEBUG - 2024-09-07 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:15 --> Total execution time: 0.0342
DEBUG - 2024-09-07 17:33:17 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:17 --> Total execution time: 0.0320
DEBUG - 2024-09-07 17:33:22 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:22 --> Total execution time: 0.0261
DEBUG - 2024-09-07 17:33:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:26 --> Total execution time: 0.0256
DEBUG - 2024-09-07 17:33:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:30 --> Total execution time: 0.0286
DEBUG - 2024-09-07 17:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:42 --> Total execution time: 0.0311
DEBUG - 2024-09-07 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:43 --> Total execution time: 0.0306
DEBUG - 2024-09-07 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:45 --> Total execution time: 0.0267
DEBUG - 2024-09-07 17:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:48 --> Total execution time: 0.0277
DEBUG - 2024-09-07 17:33:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:53 --> Total execution time: 0.0264
DEBUG - 2024-09-07 17:33:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:33:54 --> Total execution time: 0.0352
DEBUG - 2024-09-07 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:34:00 --> Total execution time: 0.0252
DEBUG - 2024-09-07 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:34:07 --> Total execution time: 0.0293
DEBUG - 2024-09-07 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:34:11 --> Total execution time: 0.0216
DEBUG - 2024-09-07 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:34:23 --> Total execution time: 0.0269
DEBUG - 2024-09-07 17:34:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-07 17:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-07 17:34:43 --> Total execution time: 0.0303
