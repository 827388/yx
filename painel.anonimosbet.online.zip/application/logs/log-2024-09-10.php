<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-10 13:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 13:59:56 --> No URI present. Default controller set.
DEBUG - 2024-09-10 13:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 13:59:56 --> Total execution time: 0.0501
DEBUG - 2024-09-10 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:01 --> No URI present. Default controller set.
DEBUG - 2024-09-10 14:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:01 --> Total execution time: 0.0334
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:21 --> UTF-8 Support Enabled
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:21 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:44:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:13 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:14 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:45:14 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:15 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:41 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:45:42 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-09-10 14:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-10 14:47:53 --> 404 Page Not Found: Painelroyalapishop/public
