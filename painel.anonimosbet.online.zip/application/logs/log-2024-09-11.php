<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-11 03:46:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-11 03:46:51 --> No URI present. Default controller set.
DEBUG - 2024-09-11 03:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-11 03:46:51 --> Total execution time: 0.0359
DEBUG - 2024-09-11 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-09-11 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-11 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-09-11 16:21:04 --> No URI present. Default controller set.
DEBUG - 2024-09-11 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-11 16:21:04 --> Total execution time: 0.0312
DEBUG - 2024-09-11 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-11 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-11 16:21:05 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-09-11 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-11 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-11 16:21:05 --> 404 Page Not Found: Apple-touch-iconpng/index
