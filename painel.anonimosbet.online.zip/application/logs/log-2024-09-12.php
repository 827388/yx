<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-12 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 13:19:58 --> No URI present. Default controller set.
DEBUG - 2024-09-12 13:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 13:19:58 --> Total execution time: 0.0423
DEBUG - 2024-09-12 13:20:01 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 13:20:01 --> No URI present. Default controller set.
DEBUG - 2024-09-12 13:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 13:20:01 --> Total execution time: 0.0362
DEBUG - 2024-09-12 13:20:17 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 13:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 13:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 13:20:18 --> Total execution time: 0.0394
DEBUG - 2024-09-12 13:20:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 13:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 13:20:21 --> Total execution time: 0.0368
DEBUG - 2024-09-12 14:58:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 14:58:48 --> No URI present. Default controller set.
DEBUG - 2024-09-12 14:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 14:58:48 --> Total execution time: 0.0265
DEBUG - 2024-09-12 23:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:33 --> No URI present. Default controller set.
DEBUG - 2024-09-12 23:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:33 --> Total execution time: 0.0353
DEBUG - 2024-09-12 23:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:35 --> No URI present. Default controller set.
DEBUG - 2024-09-12 23:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:35 --> Total execution time: 0.0219
DEBUG - 2024-09-12 23:40:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:42 --> Total execution time: 0.0418
DEBUG - 2024-09-12 23:40:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:46 --> Total execution time: 0.0268
DEBUG - 2024-09-12 23:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:52 --> Total execution time: 0.0283
DEBUG - 2024-09-12 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:54 --> Total execution time: 0.0252
DEBUG - 2024-09-12 23:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:40:56 --> Total execution time: 0.0265
DEBUG - 2024-09-12 23:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:12 --> Total execution time: 0.0243
DEBUG - 2024-09-12 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:17 --> Total execution time: 0.0279
DEBUG - 2024-09-12 23:41:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:29 --> Total execution time: 0.0244
DEBUG - 2024-09-12 23:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:34 --> Total execution time: 0.0238
DEBUG - 2024-09-12 23:41:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:38 --> Total execution time: 0.0278
DEBUG - 2024-09-12 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:45 --> Total execution time: 0.0272
DEBUG - 2024-09-12 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:50 --> No URI present. Default controller set.
DEBUG - 2024-09-12 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:50 --> Total execution time: 0.0212
DEBUG - 2024-09-12 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:54 --> Total execution time: 0.0236
DEBUG - 2024-09-12 23:41:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:41:57 --> Total execution time: 0.0278
DEBUG - 2024-09-12 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-12 23:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-12 23:42:36 --> Total execution time: 0.0220
