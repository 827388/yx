<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-13 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-13 08:53:42 --> No URI present. Default controller set.
DEBUG - 2024-09-13 08:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-13 08:53:42 --> Total execution time: 0.0325
DEBUG - 2024-09-13 17:31:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-13 17:31:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-13 17:31:25 --> 404 Page Not Found: Env/index
