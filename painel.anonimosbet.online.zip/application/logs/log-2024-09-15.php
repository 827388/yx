<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-15 17:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-15 17:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-15 17:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-15 17:31:37 --> No URI present. Default controller set.
DEBUG - 2024-09-15 17:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-15 17:31:37 --> Total execution time: 0.0237
DEBUG - 2024-09-15 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-15 17:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-15 17:31:38 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-09-15 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-15 17:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-15 17:31:38 --> 404 Page Not Found: Apple-touch-iconpng/index
