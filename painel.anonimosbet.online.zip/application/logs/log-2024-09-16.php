<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-16 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:18 --> No URI present. Default controller set.
DEBUG - 2024-09-16 16:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:18 --> Total execution time: 0.0417
DEBUG - 2024-09-16 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:27 --> Total execution time: 0.0297
DEBUG - 2024-09-16 16:52:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:29 --> Total execution time: 0.0277
DEBUG - 2024-09-16 16:52:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:58 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:52:58 --> Total execution time: 0.0238
DEBUG - 2024-09-16 16:53:10 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:10 --> Total execution time: 0.0245
DEBUG - 2024-09-16 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:19 --> Total execution time: 0.0224
DEBUG - 2024-09-16 16:53:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:23 --> No URI present. Default controller set.
DEBUG - 2024-09-16 16:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:23 --> Total execution time: 0.0198
DEBUG - 2024-09-16 16:53:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:25 --> Total execution time: 0.0227
DEBUG - 2024-09-16 16:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:29 --> Total execution time: 0.0218
DEBUG - 2024-09-16 16:53:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:30 --> Total execution time: 0.0210
DEBUG - 2024-09-16 16:53:32 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:32 --> Total execution time: 0.0244
DEBUG - 2024-09-16 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:33 --> Total execution time: 0.0240
DEBUG - 2024-09-16 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:53:34 --> Total execution time: 0.0226
DEBUG - 2024-09-16 16:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:54:12 --> Total execution time: 0.0207
DEBUG - 2024-09-16 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:54:14 --> Total execution time: 0.0210
DEBUG - 2024-09-16 16:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-16 16:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-16 16:57:23 --> Total execution time: 0.0230
