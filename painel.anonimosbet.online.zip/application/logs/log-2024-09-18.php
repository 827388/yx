<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-18 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:12:47 --> No URI present. Default controller set.
DEBUG - 2024-09-18 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:12:47 --> Total execution time: 0.0420
DEBUG - 2024-09-18 14:12:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:12:54 --> Total execution time: 0.0271
DEBUG - 2024-09-18 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:12:59 --> Total execution time: 0.0335
DEBUG - 2024-09-18 14:13:00 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:00 --> Total execution time: 0.0347
DEBUG - 2024-09-18 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:15 --> Total execution time: 0.0247
DEBUG - 2024-09-18 14:13:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:23 --> Total execution time: 0.0275
DEBUG - 2024-09-18 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:26 --> Total execution time: 0.0246
DEBUG - 2024-09-18 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:26 --> Total execution time: 0.0235
DEBUG - 2024-09-18 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:26 --> Total execution time: 0.0237
DEBUG - 2024-09-18 14:13:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:27 --> Total execution time: 0.0232
DEBUG - 2024-09-18 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:31 --> Total execution time: 0.0249
DEBUG - 2024-09-18 14:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:37 --> Total execution time: 0.0268
DEBUG - 2024-09-18 14:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:13:39 --> Total execution time: 0.0319
DEBUG - 2024-09-18 14:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:14:10 --> No URI present. Default controller set.
DEBUG - 2024-09-18 14:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:14:10 --> Total execution time: 0.0229
DEBUG - 2024-09-18 14:18:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:18:41 --> No URI present. Default controller set.
DEBUG - 2024-09-18 14:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:18:41 --> Total execution time: 0.0233
DEBUG - 2024-09-18 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:18:51 --> Total execution time: 0.0261
DEBUG - 2024-09-18 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:18:57 --> Total execution time: 0.0289
DEBUG - 2024-09-18 14:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:18:58 --> Total execution time: 0.0220
DEBUG - 2024-09-18 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:11 --> No URI present. Default controller set.
DEBUG - 2024-09-18 14:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:11 --> Total execution time: 0.0217
DEBUG - 2024-09-18 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:16 --> Total execution time: 0.0267
DEBUG - 2024-09-18 14:19:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:19 --> Total execution time: 0.0214
DEBUG - 2024-09-18 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:19:20 --> Total execution time: 0.0218
DEBUG - 2024-09-18 14:21:18 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:18 --> Total execution time: 0.0221
DEBUG - 2024-09-18 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:22 --> Total execution time: 0.0247
DEBUG - 2024-09-18 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:28 --> Total execution time: 0.0309
DEBUG - 2024-09-18 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:21:33 --> Total execution time: 0.0235
DEBUG - 2024-09-18 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:22:44 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:22:44 --> Total execution time: 0.0229
DEBUG - 2024-09-18 14:22:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:22:50 --> Total execution time: 0.0254
DEBUG - 2024-09-18 14:22:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:22:51 --> Total execution time: 0.0269
DEBUG - 2024-09-18 14:22:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 14:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 14:22:52 --> Total execution time: 0.0251
DEBUG - 2024-09-18 16:24:03 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 16:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 16:24:03 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 16:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 16:24:03 --> Total execution time: 0.0342
DEBUG - 2024-09-18 16:24:09 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 16:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 16:24:09 --> Total execution time: 0.0275
DEBUG - 2024-09-18 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 16:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 16:24:13 --> Total execution time: 0.0250
DEBUG - 2024-09-18 21:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:06:43 --> Total execution time: 0.0271
DEBUG - 2024-09-18 21:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:06:48 --> Total execution time: 0.0255
DEBUG - 2024-09-18 21:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:06:59 --> Total execution time: 0.0255
DEBUG - 2024-09-18 21:07:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:07:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-18 21:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-18 21:07:07 --> Total execution time: 0.0236
