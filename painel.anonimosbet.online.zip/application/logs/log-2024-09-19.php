<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-19 01:03:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-19 01:03:52 --> No URI present. Default controller set.
DEBUG - 2024-09-19 01:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-19 01:03:52 --> Total execution time: 0.0249
DEBUG - 2024-09-19 01:03:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-19 01:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-19 01:03:53 --> Total execution time: 0.0237
DEBUG - 2024-09-19 01:03:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-19 01:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-19 01:03:53 --> 404 Page Not Found: Login/index
