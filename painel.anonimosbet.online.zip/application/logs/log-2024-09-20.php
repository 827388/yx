<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-20 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:50 --> No URI present. Default controller set.
DEBUG - 2024-09-20 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:35:50 --> Total execution time: 0.0304
DEBUG - 2024-09-20 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-20 11:35:50 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-09-20 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-20 11:35:50 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-09-20 11:35:58 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:35:59 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:35:59 --> Total execution time: 0.0405
DEBUG - 2024-09-20 11:36:04 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:04 --> Total execution time: 0.0346
DEBUG - 2024-09-20 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:13 --> Total execution time: 0.0287
DEBUG - 2024-09-20 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:14 --> Total execution time: 0.0408
DEBUG - 2024-09-20 11:36:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:15 --> Total execution time: 0.0265
DEBUG - 2024-09-20 11:36:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:16 --> Total execution time: 0.0322
DEBUG - 2024-09-20 11:36:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:38 --> Total execution time: 0.0284
DEBUG - 2024-09-20 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:39 --> Total execution time: 0.0294
DEBUG - 2024-09-20 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:39 --> Total execution time: 0.0268
DEBUG - 2024-09-20 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:42 --> Total execution time: 0.0272
DEBUG - 2024-09-20 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-20 11:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-20 11:36:45 --> Total execution time: 0.0289
