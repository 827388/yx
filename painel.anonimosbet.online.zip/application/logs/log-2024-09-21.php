<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-21 06:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-09-21 06:18:35 --> No URI present. Default controller set.
DEBUG - 2024-09-21 06:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-21 06:18:35 --> Total execution time: 0.0375
DEBUG - 2024-09-21 21:29:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-21 21:29:24 --> No URI present. Default controller set.
DEBUG - 2024-09-21 21:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-21 21:29:24 --> Total execution time: 0.0452
DEBUG - 2024-09-21 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-09-21 22:54:47 --> No URI present. Default controller set.
DEBUG - 2024-09-21 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-21 22:54:47 --> Total execution time: 0.0248
DEBUG - 2024-09-21 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-21 22:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-21 22:54:50 --> 404 Page Not Found: Robotstxt/index
