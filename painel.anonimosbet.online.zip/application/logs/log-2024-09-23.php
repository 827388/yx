<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-23 07:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:40:53 --> No URI present. Default controller set.
DEBUG - 2024-09-23 07:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:40:53 --> Total execution time: 0.0247
DEBUG - 2024-09-23 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:40:57 --> Total execution time: 0.0331
DEBUG - 2024-09-23 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:40:58 --> Total execution time: 0.0265
DEBUG - 2024-09-23 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:41:18 --> No URI present. Default controller set.
DEBUG - 2024-09-23 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:41:18 --> Total execution time: 0.0213
DEBUG - 2024-09-23 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:41:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:41:26 --> Total execution time: 0.0234
DEBUG - 2024-09-23 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 07:41:30 --> Total execution time: 0.0284
DEBUG - 2024-09-23 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 08:24:33 --> Total execution time: 0.0289
DEBUG - 2024-09-23 17:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:36 --> No URI present. Default controller set.
DEBUG - 2024-09-23 17:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:36 --> Total execution time: 0.0435
DEBUG - 2024-09-23 17:25:39 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:39 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:40 --> Total execution time: 0.0495
DEBUG - 2024-09-23 17:25:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:42 --> Total execution time: 0.0351
DEBUG - 2024-09-23 17:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:53 --> Total execution time: 0.0355
DEBUG - 2024-09-23 17:25:56 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:25:56 --> Total execution time: 0.0290
DEBUG - 2024-09-23 17:26:20 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:20 --> Total execution time: 0.0339
DEBUG - 2024-09-23 17:26:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:24 --> Total execution time: 0.0352
DEBUG - 2024-09-23 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:27 --> No URI present. Default controller set.
DEBUG - 2024-09-23 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:27 --> Total execution time: 0.0262
DEBUG - 2024-09-23 17:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:30 --> Total execution time: 0.0287
DEBUG - 2024-09-23 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:33 --> Total execution time: 0.0245
DEBUG - 2024-09-23 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:35 --> Total execution time: 0.0255
DEBUG - 2024-09-23 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:36 --> Total execution time: 0.0322
DEBUG - 2024-09-23 17:26:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:26:37 --> Total execution time: 0.0283
DEBUG - 2024-09-23 17:35:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-23 17:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-23 17:35:24 --> Total execution time: 0.0270
