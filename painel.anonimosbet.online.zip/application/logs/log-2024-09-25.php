<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-25 15:56:26 --> UTF-8 Support Enabled
DEBUG - 2024-09-25 15:56:26 --> No URI present. Default controller set.
DEBUG - 2024-09-25 15:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-25 15:56:26 --> Total execution time: 0.0408
