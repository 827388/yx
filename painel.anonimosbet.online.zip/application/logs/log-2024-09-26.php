<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-26 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-26 06:32:23 --> No URI present. Default controller set.
DEBUG - 2024-09-26 06:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-26 06:32:23 --> Total execution time: 0.0407
DEBUG - 2024-09-26 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-09-26 14:10:08 --> No URI present. Default controller set.
DEBUG - 2024-09-26 14:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-26 14:10:08 --> Total execution time: 0.0458
