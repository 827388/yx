<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-27 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:06 --> No URI present. Default controller set.
DEBUG - 2024-09-27 16:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:06 --> Total execution time: 0.0435
DEBUG - 2024-09-27 16:55:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:13 --> Total execution time: 0.0294
DEBUG - 2024-09-27 16:55:20 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:20 --> Total execution time: 0.0280
DEBUG - 2024-09-27 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:55:48 --> Total execution time: 0.0249
DEBUG - 2024-09-27 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:01 --> Total execution time: 0.0384
DEBUG - 2024-09-27 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:17 --> Total execution time: 0.0278
DEBUG - 2024-09-27 16:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:23 --> Total execution time: 0.0243
DEBUG - 2024-09-27 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:29 --> Total execution time: 0.0240
DEBUG - 2024-09-27 16:56:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:37 --> Total execution time: 0.0226
DEBUG - 2024-09-27 16:56:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:48 --> Total execution time: 0.0269
DEBUG - 2024-09-27 16:56:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:52 --> Total execution time: 0.0222
DEBUG - 2024-09-27 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:56:54 --> Total execution time: 0.0241
DEBUG - 2024-09-27 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:57:00 --> Total execution time: 0.0243
DEBUG - 2024-09-27 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 16:57:05 --> Total execution time: 0.0240
DEBUG - 2024-09-27 17:01:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:01:43 --> Total execution time: 0.0239
DEBUG - 2024-09-27 17:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:01:46 --> Total execution time: 0.0268
DEBUG - 2024-09-27 17:01:49 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:01:49 --> Total execution time: 0.0218
DEBUG - 2024-09-27 17:03:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:19 --> Total execution time: 0.0239
DEBUG - 2024-09-27 17:03:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:27 --> Total execution time: 0.0227
DEBUG - 2024-09-27 17:03:40 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:40 --> Total execution time: 0.0256
DEBUG - 2024-09-27 17:03:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:41 --> Total execution time: 0.0227
DEBUG - 2024-09-27 17:03:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:43 --> Total execution time: 0.0224
DEBUG - 2024-09-27 17:03:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:43 --> Total execution time: 0.0218
DEBUG - 2024-09-27 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:45 --> Total execution time: 0.0221
DEBUG - 2024-09-27 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:45 --> Total execution time: 0.0247
DEBUG - 2024-09-27 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:03:51 --> Total execution time: 0.0215
DEBUG - 2024-09-27 17:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:04:38 --> No URI present. Default controller set.
DEBUG - 2024-09-27 17:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:04:38 --> Total execution time: 0.0221
DEBUG - 2024-09-27 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:04:42 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:04:42 --> Total execution time: 0.0247
DEBUG - 2024-09-27 17:04:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:04:43 --> Total execution time: 0.0222
DEBUG - 2024-09-27 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:05:23 --> Total execution time: 0.0232
DEBUG - 2024-09-27 17:05:54 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:05:55 --> No URI present. Default controller set.
DEBUG - 2024-09-27 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:05:55 --> Total execution time: 0.0205
DEBUG - 2024-09-27 17:06:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:14 --> Total execution time: 0.0212
DEBUG - 2024-09-27 17:06:16 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:16 --> Total execution time: 0.0252
DEBUG - 2024-09-27 17:06:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:30 --> No URI present. Default controller set.
DEBUG - 2024-09-27 17:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:30 --> Total execution time: 0.0213
DEBUG - 2024-09-27 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:36 --> Total execution time: 0.0246
DEBUG - 2024-09-27 17:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:06:38 --> Total execution time: 0.0218
DEBUG - 2024-09-27 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:07:32 --> Total execution time: 0.0242
DEBUG - 2024-09-27 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:05 --> Total execution time: 0.0309
DEBUG - 2024-09-27 17:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:07 --> Total execution time: 0.0247
DEBUG - 2024-09-27 17:08:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:23 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:08:23 --> Total execution time: 0.0230
DEBUG - 2024-09-27 17:11:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:11:14 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:11:14 --> Total execution time: 0.0236
DEBUG - 2024-09-27 17:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:15 --> Total execution time: 0.0211
DEBUG - 2024-09-27 17:29:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:19 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:19 --> Total execution time: 0.0227
DEBUG - 2024-09-27 17:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 17:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 17:29:48 --> Total execution time: 0.0211
DEBUG - 2024-09-27 19:22:31 --> UTF-8 Support Enabled
DEBUG - 2024-09-27 19:22:31 --> No URI present. Default controller set.
DEBUG - 2024-09-27 19:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-27 19:22:31 --> Total execution time: 0.0243
