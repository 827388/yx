<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-09-28 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:24 --> No URI present. Default controller set.
DEBUG - 2024-09-28 02:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:24 --> Total execution time: 0.0207
DEBUG - 2024-09-28 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-28 02:30:24 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-09-28 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-09-28 02:30:24 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-09-28 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:35 --> Total execution time: 0.0270
DEBUG - 2024-09-28 02:30:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:37 --> Total execution time: 0.0217
DEBUG - 2024-09-28 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:30:52 --> Total execution time: 0.0270
DEBUG - 2024-09-28 02:31:03 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:03 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:03 --> Total execution time: 0.0270
DEBUG - 2024-09-28 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:06 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:06 --> No URI present. Default controller set.
DEBUG - 2024-09-28 02:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:06 --> Total execution time: 0.0213
DEBUG - 2024-09-28 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:11 --> Total execution time: 0.0243
DEBUG - 2024-09-28 02:31:13 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:13 --> Total execution time: 0.0238
DEBUG - 2024-09-28 02:31:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:21 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:21 --> No URI present. Default controller set.
DEBUG - 2024-09-28 02:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:21 --> Total execution time: 0.0206
DEBUG - 2024-09-28 02:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:25 --> Total execution time: 0.0231
DEBUG - 2024-09-28 02:31:27 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:27 --> Total execution time: 0.0225
DEBUG - 2024-09-28 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:30 --> Total execution time: 0.0208
DEBUG - 2024-09-28 02:31:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:33 --> No URI present. Default controller set.
DEBUG - 2024-09-28 02:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:33 --> Total execution time: 0.0229
DEBUG - 2024-09-28 02:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:37 --> Total execution time: 0.0222
DEBUG - 2024-09-28 02:31:38 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:38 --> Total execution time: 0.0224
DEBUG - 2024-09-28 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:43 --> No URI present. Default controller set.
DEBUG - 2024-09-28 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:43 --> Total execution time: 0.0218
DEBUG - 2024-09-28 02:31:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:50 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:50 --> Total execution time: 0.0191
DEBUG - 2024-09-28 02:31:51 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:31:51 --> Total execution time: 0.0193
DEBUG - 2024-09-28 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:25 --> Total execution time: 0.0214
DEBUG - 2024-09-28 02:32:28 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:28 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:28 --> Total execution time: 0.0202
DEBUG - 2024-09-28 02:32:29 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:29 --> Total execution time: 0.0266
DEBUG - 2024-09-28 02:32:33 --> UTF-8 Support Enabled
DEBUG - 2024-09-28 02:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-09-28 02:32:33 --> Total execution time: 0.0194
