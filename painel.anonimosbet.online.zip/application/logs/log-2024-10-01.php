<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-01 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 17:03:03 --> No URI present. Default controller set.
DEBUG - 2024-10-01 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 17:03:03 --> Total execution time: 0.0234
DEBUG - 2024-10-01 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:51:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:51:08 --> Total execution time: 0.0307
DEBUG - 2024-10-01 23:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:51:12 --> Total execution time: 0.0277
DEBUG - 2024-10-01 23:51:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:51:16 --> Total execution time: 0.0314
DEBUG - 2024-10-01 23:53:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:04 --> Total execution time: 0.0306
DEBUG - 2024-10-01 23:53:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:35 --> Total execution time: 0.0227
DEBUG - 2024-10-01 23:53:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:41 --> Total execution time: 0.0255
DEBUG - 2024-10-01 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:46 --> No URI present. Default controller set.
DEBUG - 2024-10-01 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:46 --> Total execution time: 0.0180
DEBUG - 2024-10-01 23:53:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:57 --> Total execution time: 0.0212
DEBUG - 2024-10-01 23:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:53:59 --> Total execution time: 0.0206
DEBUG - 2024-10-01 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:54:48 --> Total execution time: 0.0205
DEBUG - 2024-10-01 23:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:55:54 --> Total execution time: 0.0214
DEBUG - 2024-10-01 23:55:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:55:56 --> Total execution time: 0.0220
DEBUG - 2024-10-01 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:55:59 --> Total execution time: 0.0218
DEBUG - 2024-10-01 23:56:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:01 --> Total execution time: 0.0346
DEBUG - 2024-10-01 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:03 --> Total execution time: 0.0242
DEBUG - 2024-10-01 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:05 --> Total execution time: 0.0205
DEBUG - 2024-10-01 23:56:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:08 --> Total execution time: 0.0218
DEBUG - 2024-10-01 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:11 --> Total execution time: 0.0212
DEBUG - 2024-10-01 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:14 --> No URI present. Default controller set.
DEBUG - 2024-10-01 23:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:14 --> Total execution time: 0.0215
DEBUG - 2024-10-01 23:56:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:19 --> Total execution time: 0.0224
DEBUG - 2024-10-01 23:56:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:20 --> Total execution time: 0.0189
DEBUG - 2024-10-01 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:24 --> Total execution time: 0.0225
DEBUG - 2024-10-01 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:28 --> Total execution time: 0.0216
DEBUG - 2024-10-01 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:32 --> Total execution time: 0.0225
DEBUG - 2024-10-01 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:42 --> Total execution time: 0.0207
DEBUG - 2024-10-01 23:56:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:50 --> Total execution time: 0.0187
DEBUG - 2024-10-01 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:52 --> Total execution time: 0.0237
DEBUG - 2024-10-01 23:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:56:55 --> No URI present. Default controller set.
DEBUG - 2024-10-01 23:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:56:55 --> Total execution time: 0.0209
DEBUG - 2024-10-01 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:57:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:57:06 --> Total execution time: 0.0254
DEBUG - 2024-10-01 23:57:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:57:46 --> Total execution time: 0.0228
DEBUG - 2024-10-01 23:58:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:58:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-01 23:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-01 23:58:09 --> Total execution time: 0.0222
