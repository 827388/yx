<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-02 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-02 11:30:14 --> No URI present. Default controller set.
DEBUG - 2024-10-02 11:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-02 11:30:14 --> Total execution time: 0.0385
DEBUG - 2024-10-02 15:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-02 15:23:57 --> No URI present. Default controller set.
DEBUG - 2024-10-02 15:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-02 15:23:57 --> Total execution time: 0.0247
