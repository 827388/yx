<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-04 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-04 13:49:00 --> No URI present. Default controller set.
DEBUG - 2024-10-04 13:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-04 13:49:00 --> Total execution time: 0.0505
