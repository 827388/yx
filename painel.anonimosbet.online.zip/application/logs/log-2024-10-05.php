<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-05 15:26:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:06 --> No URI present. Default controller set.
DEBUG - 2024-10-05 15:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:06 --> Total execution time: 0.0400
DEBUG - 2024-10-05 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:19 --> Total execution time: 0.0240
DEBUG - 2024-10-05 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:31 --> Total execution time: 0.0271
DEBUG - 2024-10-05 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:34 --> Total execution time: 0.0246
DEBUG - 2024-10-05 15:26:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:37 --> Total execution time: 0.0250
DEBUG - 2024-10-05 15:26:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:46 --> No URI present. Default controller set.
DEBUG - 2024-10-05 15:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:46 --> Total execution time: 0.0200
DEBUG - 2024-10-05 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:56 --> Total execution time: 0.0227
DEBUG - 2024-10-05 15:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:26:58 --> Total execution time: 0.0259
DEBUG - 2024-10-05 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:27:14 --> No URI present. Default controller set.
DEBUG - 2024-10-05 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:27:14 --> Total execution time: 0.0196
DEBUG - 2024-10-05 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:27:20 --> Total execution time: 0.0213
DEBUG - 2024-10-05 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:27:24 --> Total execution time: 0.0225
DEBUG - 2024-10-05 15:29:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:29:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:29:47 --> Total execution time: 0.0192
DEBUG - 2024-10-05 15:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 15:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 15:34:15 --> Total execution time: 0.0275
DEBUG - 2024-10-05 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 17:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 17:28:33 --> Total execution time: 0.0270
DEBUG - 2024-10-05 23:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 23:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 23:02:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 23:02:26 --> No URI present. Default controller set.
DEBUG - 2024-10-05 23:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 23:02:26 --> Total execution time: 0.0213
DEBUG - 2024-10-05 23:02:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-05 23:02:27 --> No URI present. Default controller set.
DEBUG - 2024-10-05 23:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-05 23:02:27 --> Total execution time: 0.0184
