<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-08 18:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-08 18:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-08 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-08 18:43:51 --> No URI present. Default controller set.
DEBUG - 2024-10-08 18:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-08 18:43:51 --> Total execution time: 0.0207
DEBUG - 2024-10-08 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-08 18:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-08 18:43:51 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-08 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-08 18:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-08 18:43:51 --> 404 Page Not Found: Apple-touch-iconpng/index
