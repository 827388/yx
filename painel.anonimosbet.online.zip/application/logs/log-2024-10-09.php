<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-09 01:47:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-09 01:47:09 --> No URI present. Default controller set.
DEBUG - 2024-10-09 01:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-09 01:47:09 --> Total execution time: 0.0411
DEBUG - 2024-10-09 13:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-09 13:55:58 --> No URI present. Default controller set.
DEBUG - 2024-10-09 13:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-09 13:55:58 --> Total execution time: 0.0486
DEBUG - 2024-10-09 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-09 15:12:02 --> No URI present. Default controller set.
DEBUG - 2024-10-09 15:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-09 15:12:02 --> Total execution time: 0.0520
DEBUG - 2024-10-09 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-09 22:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-09 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-09 22:18:36 --> No URI present. Default controller set.
DEBUG - 2024-10-09 22:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-09 22:18:36 --> Total execution time: 0.0227
