<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-10 00:05:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 00:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 00:05:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 00:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 00:05:11 --> Total execution time: 0.0360
DEBUG - 2024-10-10 00:05:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 00:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 00:05:14 --> Total execution time: 0.0267
DEBUG - 2024-10-10 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 01:24:56 --> Total execution time: 0.0242
DEBUG - 2024-10-10 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:05:33 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:05:33 --> Total execution time: 0.0246
DEBUG - 2024-10-10 09:05:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:05:36 --> Total execution time: 0.0288
DEBUG - 2024-10-10 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:05:37 --> Total execution time: 0.0260
DEBUG - 2024-10-10 09:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:06:26 --> Total execution time: 0.0252
DEBUG - 2024-10-10 09:06:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:06:46 --> Total execution time: 0.0283
DEBUG - 2024-10-10 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:07 --> Total execution time: 0.0343
DEBUG - 2024-10-10 09:07:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:13 --> Total execution time: 0.0249
DEBUG - 2024-10-10 09:07:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:16 --> Total execution time: 0.0271
DEBUG - 2024-10-10 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:25 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:25 --> Total execution time: 0.0205
DEBUG - 2024-10-10 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:33 --> Total execution time: 0.0208
DEBUG - 2024-10-10 09:07:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:07:42 --> Total execution time: 0.0192
DEBUG - 2024-10-10 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:16 --> Total execution time: 0.0301
DEBUG - 2024-10-10 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:18 --> Total execution time: 0.0292
DEBUG - 2024-10-10 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:30 --> Total execution time: 0.0325
DEBUG - 2024-10-10 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:36 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:36 --> Total execution time: 0.0217
DEBUG - 2024-10-10 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:46 --> Total execution time: 0.0260
DEBUG - 2024-10-10 09:11:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:52 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:52 --> Total execution time: 0.0210
DEBUG - 2024-10-10 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:56 --> Total execution time: 0.0233
DEBUG - 2024-10-10 09:11:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:11:57 --> Total execution time: 0.0224
DEBUG - 2024-10-10 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:02 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:02 --> Total execution time: 0.0320
DEBUG - 2024-10-10 09:12:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:13 --> Total execution time: 0.0244
DEBUG - 2024-10-10 09:12:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:24 --> Total execution time: 0.0203
DEBUG - 2024-10-10 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:29 --> Total execution time: 0.0285
DEBUG - 2024-10-10 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:31 --> Total execution time: 0.0226
DEBUG - 2024-10-10 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:38 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:38 --> Total execution time: 0.0214
DEBUG - 2024-10-10 09:12:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:47 --> Total execution time: 0.0237
DEBUG - 2024-10-10 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:12:49 --> Total execution time: 0.0231
DEBUG - 2024-10-10 09:13:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:13:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:13:24 --> Total execution time: 0.0244
DEBUG - 2024-10-10 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:02 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:02 --> Total execution time: 0.0261
DEBUG - 2024-10-10 09:14:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:07 --> Total execution time: 0.0270
DEBUG - 2024-10-10 09:14:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:08 --> Total execution time: 0.0219
DEBUG - 2024-10-10 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:11 --> No URI present. Default controller set.
DEBUG - 2024-10-10 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:11 --> Total execution time: 0.0206
DEBUG - 2024-10-10 09:14:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:24 --> Total execution time: 0.0270
DEBUG - 2024-10-10 09:14:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:28 --> Total execution time: 0.0242
DEBUG - 2024-10-10 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:33 --> Total execution time: 0.0255
DEBUG - 2024-10-10 09:14:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:36 --> Total execution time: 0.0264
DEBUG - 2024-10-10 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:14:37 --> Total execution time: 0.0217
DEBUG - 2024-10-10 09:17:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:17:09 --> Total execution time: 0.0248
DEBUG - 2024-10-10 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 09:17:19 --> Total execution time: 0.0240
DEBUG - 2024-10-10 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:05 --> No URI present. Default controller set.
DEBUG - 2024-10-10 14:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:05 --> Total execution time: 0.0373
DEBUG - 2024-10-10 14:10:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:30 --> Total execution time: 0.0318
DEBUG - 2024-10-10 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:38 --> No URI present. Default controller set.
DEBUG - 2024-10-10 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:38 --> Total execution time: 0.0202
DEBUG - 2024-10-10 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:10:59 --> Total execution time: 0.0301
DEBUG - 2024-10-10 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:11:56 --> Total execution time: 0.0234
DEBUG - 2024-10-10 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:12:31 --> Total execution time: 0.0285
DEBUG - 2024-10-10 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:12:37 --> Total execution time: 0.0296
DEBUG - 2024-10-10 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:32 --> No URI present. Default controller set.
DEBUG - 2024-10-10 14:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:32 --> Total execution time: 0.0225
DEBUG - 2024-10-10 14:13:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:40 --> Total execution time: 0.0259
DEBUG - 2024-10-10 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:42 --> Total execution time: 0.0247
DEBUG - 2024-10-10 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:45 --> Total execution time: 0.0205
DEBUG - 2024-10-10 14:13:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:51 --> Total execution time: 0.0238
DEBUG - 2024-10-10 14:13:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 14:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 14:13:55 --> Total execution time: 0.0208
DEBUG - 2024-10-10 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 15:33:56 --> No URI present. Default controller set.
DEBUG - 2024-10-10 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 15:33:56 --> Total execution time: 0.0202
DEBUG - 2024-10-10 15:33:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 15:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 15:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 15:33:59 --> Total execution time: 0.0220
DEBUG - 2024-10-10 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-10 15:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-10 15:34:01 --> Total execution time: 0.0290
