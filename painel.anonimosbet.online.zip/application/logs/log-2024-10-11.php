<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-11 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-11 10:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-11 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-11 10:54:36 --> No URI present. Default controller set.
DEBUG - 2024-10-11 10:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-11 10:54:36 --> Total execution time: 0.0220
