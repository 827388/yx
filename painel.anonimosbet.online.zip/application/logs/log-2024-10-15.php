<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-15 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 10:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-15 10:41:20 --> 404 Page Not Found: Metrics/index
DEBUG - 2024-10-15 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 10:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-15 10:41:20 --> 404 Page Not Found: Metrics/index
DEBUG - 2024-10-15 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 15:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-15 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 15:04:15 --> No URI present. Default controller set.
DEBUG - 2024-10-15 15:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-15 15:04:15 --> Total execution time: 0.0235
DEBUG - 2024-10-15 15:04:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 15:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-15 15:04:16 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-15 15:04:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 15:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-15 15:04:16 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-15 20:08:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 20:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-15 20:08:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-15 20:08:06 --> No URI present. Default controller set.
DEBUG - 2024-10-15 20:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-15 20:08:06 --> Total execution time: 0.0211
