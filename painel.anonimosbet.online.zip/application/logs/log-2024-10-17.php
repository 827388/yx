<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-17 22:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:06 --> No URI present. Default controller set.
DEBUG - 2024-10-17 22:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:06 --> Total execution time: 0.0376
DEBUG - 2024-10-17 22:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:08 --> Total execution time: 0.0292
DEBUG - 2024-10-17 22:47:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:12 --> Total execution time: 0.0260
DEBUG - 2024-10-17 22:47:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:13 --> Total execution time: 0.0278
DEBUG - 2024-10-17 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:14 --> Total execution time: 0.0241
DEBUG - 2024-10-17 22:47:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:17 --> Total execution time: 0.0250
DEBUG - 2024-10-17 22:47:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:19 --> Total execution time: 0.0192
DEBUG - 2024-10-17 22:47:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:29 --> Total execution time: 0.0230
DEBUG - 2024-10-17 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:36 --> Total execution time: 0.0212
DEBUG - 2024-10-17 22:47:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:40 --> Total execution time: 0.0209
DEBUG - 2024-10-17 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:47:54 --> Total execution time: 0.0211
DEBUG - 2024-10-17 22:48:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:09 --> Total execution time: 0.0263
DEBUG - 2024-10-17 22:48:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:17 --> Total execution time: 0.0273
DEBUG - 2024-10-17 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:26 --> No URI present. Default controller set.
DEBUG - 2024-10-17 22:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:26 --> Total execution time: 0.0209
DEBUG - 2024-10-17 22:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:28 --> Total execution time: 0.0223
DEBUG - 2024-10-17 22:48:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:32 --> Total execution time: 0.0216
DEBUG - 2024-10-17 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:35 --> Total execution time: 0.0246
DEBUG - 2024-10-17 22:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:36 --> Total execution time: 0.0278
DEBUG - 2024-10-17 22:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:37 --> Total execution time: 0.0222
DEBUG - 2024-10-17 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:48:37 --> Total execution time: 0.0222
DEBUG - 2024-10-17 22:49:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:03 --> Total execution time: 0.0215
DEBUG - 2024-10-17 22:49:21 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:21 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:21 --> Total execution time: 0.0230
DEBUG - 2024-10-17 22:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:24 --> No URI present. Default controller set.
DEBUG - 2024-10-17 22:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:24 --> Total execution time: 0.0188
DEBUG - 2024-10-17 22:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:28 --> Total execution time: 0.0215
DEBUG - 2024-10-17 22:49:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:31 --> Total execution time: 0.0243
DEBUG - 2024-10-17 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:36 --> No URI present. Default controller set.
DEBUG - 2024-10-17 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:36 --> Total execution time: 0.0200
DEBUG - 2024-10-17 22:49:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:38 --> Total execution time: 0.0237
DEBUG - 2024-10-17 22:49:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 22:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 22:49:41 --> Total execution time: 0.0211
DEBUG - 2024-10-17 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:19 --> Total execution time: 0.0269
DEBUG - 2024-10-17 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:30 --> No URI present. Default controller set.
DEBUG - 2024-10-17 23:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:30 --> Total execution time: 0.0206
DEBUG - 2024-10-17 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:32 --> Total execution time: 0.0231
DEBUG - 2024-10-17 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:36 --> No URI present. Default controller set.
DEBUG - 2024-10-17 23:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:36 --> Total execution time: 0.0194
DEBUG - 2024-10-17 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-17 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 23:03:41 --> Total execution time: 0.0254
