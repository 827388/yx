<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-19 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:25 --> No URI present. Default controller set.
DEBUG - 2024-10-19 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:25 --> Total execution time: 0.0483
DEBUG - 2024-10-19 22:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:29 --> No URI present. Default controller set.
DEBUG - 2024-10-19 22:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:29 --> Total execution time: 0.0226
DEBUG - 2024-10-19 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:39 --> Total execution time: 0.0218
DEBUG - 2024-10-19 22:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:46 --> Total execution time: 0.0246
DEBUG - 2024-10-19 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:48 --> Total execution time: 0.0234
DEBUG - 2024-10-19 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-19 22:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:17:50 --> Total execution time: 0.0210
