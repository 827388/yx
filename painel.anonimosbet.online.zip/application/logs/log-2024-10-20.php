<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-20 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:23:21 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:23:21 --> Total execution time: 0.0503
DEBUG - 2024-10-20 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:23:23 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:23:23 --> Total execution time: 0.0265
DEBUG - 2024-10-20 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:23:27 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:23:27 --> Total execution time: 0.0258
DEBUG - 2024-10-20 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:23:36 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:23:36 --> Total execution time: 0.0282
DEBUG - 2024-10-20 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:23:55 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:23:55 --> Total execution time: 0.0246
DEBUG - 2024-10-20 04:25:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:25:05 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:25:05 --> Total execution time: 0.0219
DEBUG - 2024-10-20 04:25:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-20 04:25:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-10-20 04:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 04:57:51 --> No URI present. Default controller set.
DEBUG - 2024-10-20 04:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 04:57:51 --> Total execution time: 0.0234
DEBUG - 2024-10-20 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 05:01:54 --> No URI present. Default controller set.
DEBUG - 2024-10-20 05:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 05:01:54 --> Total execution time: 0.0236
DEBUG - 2024-10-20 07:27:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 07:27:35 --> No URI present. Default controller set.
DEBUG - 2024-10-20 07:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 07:27:35 --> Total execution time: 0.0279
DEBUG - 2024-10-20 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:14 --> No URI present. Default controller set.
DEBUG - 2024-10-20 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:14 --> Total execution time: 0.0232
DEBUG - 2024-10-20 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:24 --> Total execution time: 0.0308
DEBUG - 2024-10-20 12:34:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:26 --> Total execution time: 0.0236
DEBUG - 2024-10-20 12:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:28 --> Total execution time: 0.0263
DEBUG - 2024-10-20 12:34:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:30 --> Total execution time: 0.0309
DEBUG - 2024-10-20 12:34:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:34:30 --> Total execution time: 0.0238
DEBUG - 2024-10-20 12:36:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 12:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 12:36:32 --> Total execution time: 0.0234
DEBUG - 2024-10-20 15:18:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 15:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 15:18:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 15:18:51 --> No URI present. Default controller set.
DEBUG - 2024-10-20 15:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 15:18:51 --> Total execution time: 0.0209
DEBUG - 2024-10-20 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 15:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 15:20:52 --> No URI present. Default controller set.
DEBUG - 2024-10-20 15:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 15:20:52 --> Total execution time: 0.0217
DEBUG - 2024-10-20 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 16:22:43 --> No URI present. Default controller set.
DEBUG - 2024-10-20 16:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 16:22:43 --> Total execution time: 0.0204
DEBUG - 2024-10-20 20:03:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:03:51 --> No URI present. Default controller set.
DEBUG - 2024-10-20 20:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:03:51 --> Total execution time: 0.0285
DEBUG - 2024-10-20 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:06 --> Total execution time: 0.0326
DEBUG - 2024-10-20 20:04:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:12 --> Total execution time: 0.0300
DEBUG - 2024-10-20 20:04:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:16 --> Total execution time: 0.0235
DEBUG - 2024-10-20 20:04:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:04:22 --> Total execution time: 0.0213
DEBUG - 2024-10-20 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:00 --> Total execution time: 0.0367
DEBUG - 2024-10-20 20:05:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:03 --> Total execution time: 0.0426
DEBUG - 2024-10-20 20:05:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:13 --> Total execution time: 0.0213
DEBUG - 2024-10-20 20:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:28 --> Total execution time: 0.0242
DEBUG - 2024-10-20 20:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:35 --> No URI present. Default controller set.
DEBUG - 2024-10-20 20:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:35 --> Total execution time: 0.0293
DEBUG - 2024-10-20 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:44 --> Total execution time: 0.0224
DEBUG - 2024-10-20 20:05:53 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:05:54 --> Total execution time: 0.0251
DEBUG - 2024-10-20 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:01 --> Total execution time: 0.0296
DEBUG - 2024-10-20 20:06:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:04 --> Total execution time: 0.0263
DEBUG - 2024-10-20 20:06:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:06 --> No URI present. Default controller set.
DEBUG - 2024-10-20 20:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:06 --> Total execution time: 0.0218
DEBUG - 2024-10-20 20:06:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:14 --> Total execution time: 0.0208
DEBUG - 2024-10-20 20:06:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:25 --> Total execution time: 0.0257
DEBUG - 2024-10-20 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:29 --> Total execution time: 0.0237
DEBUG - 2024-10-20 20:06:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:32 --> Total execution time: 0.0212
DEBUG - 2024-10-20 20:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:36 --> Total execution time: 0.0269
DEBUG - 2024-10-20 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:06:56 --> Total execution time: 0.0208
DEBUG - 2024-10-20 20:07:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:09 --> Total execution time: 0.0230
DEBUG - 2024-10-20 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:11 --> Total execution time: 0.0277
DEBUG - 2024-10-20 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:20 --> Total execution time: 0.0238
DEBUG - 2024-10-20 20:07:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:24 --> Total execution time: 0.0260
DEBUG - 2024-10-20 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:25 --> Total execution time: 0.0232
DEBUG - 2024-10-20 20:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:26 --> Total execution time: 0.0220
DEBUG - 2024-10-20 20:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:31 --> Total execution time: 0.0234
DEBUG - 2024-10-20 20:07:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:39 --> Total execution time: 0.0222
DEBUG - 2024-10-20 20:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:43 --> Total execution time: 0.0233
DEBUG - 2024-10-20 20:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:45 --> Total execution time: 0.0228
DEBUG - 2024-10-20 20:07:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:07:46 --> Total execution time: 0.0225
DEBUG - 2024-10-20 20:08:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:04 --> Total execution time: 0.0306
DEBUG - 2024-10-20 20:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:07 --> Total execution time: 0.0245
DEBUG - 2024-10-20 20:08:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:08 --> Total execution time: 0.0269
DEBUG - 2024-10-20 20:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:10 --> Total execution time: 0.0333
DEBUG - 2024-10-20 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:37 --> No URI present. Default controller set.
DEBUG - 2024-10-20 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:37 --> Total execution time: 0.0253
DEBUG - 2024-10-20 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:44 --> Total execution time: 0.0367
DEBUG - 2024-10-20 20:08:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:47 --> Total execution time: 0.0254
DEBUG - 2024-10-20 20:08:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:08:50 --> Total execution time: 0.0247
DEBUG - 2024-10-20 20:27:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-20 20:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-20 20:27:48 --> Total execution time: 0.0285
