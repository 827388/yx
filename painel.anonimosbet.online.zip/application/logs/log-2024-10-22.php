<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-22 01:52:23 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 01:52:23 --> No URI present. Default controller set.
DEBUG - 2024-10-22 01:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 01:52:23 --> Total execution time: 0.0514
DEBUG - 2024-10-22 01:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 01:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 01:52:24 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-22 01:52:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 01:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 01:52:24 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-22 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 06:38:59 --> No URI present. Default controller set.
DEBUG - 2024-10-22 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 06:38:59 --> Total execution time: 0.0866
DEBUG - 2024-10-22 06:46:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 06:46:37 --> No URI present. Default controller set.
DEBUG - 2024-10-22 06:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 06:46:37 --> Total execution time: 0.0276
DEBUG - 2024-10-22 06:50:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 06:50:13 --> No URI present. Default controller set.
DEBUG - 2024-10-22 06:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 06:50:13 --> Total execution time: 0.0246
DEBUG - 2024-10-22 07:56:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 07:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 07:56:07 --> 404 Page Not Found: Wp-admin/setup-config.php
DEBUG - 2024-10-22 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 07:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 07:56:08 --> 404 Page Not Found: Wordpress/wp-admin
DEBUG - 2024-10-22 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:29 --> No URI present. Default controller set.
DEBUG - 2024-10-22 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:30 --> Total execution time: 0.0274
DEBUG - 2024-10-22 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:30 --> No URI present. Default controller set.
DEBUG - 2024-10-22 08:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:30 --> Total execution time: 0.0251
DEBUG - 2024-10-22 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:33 --> Total execution time: 0.0575
DEBUG - 2024-10-22 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:38 --> No URI present. Default controller set.
DEBUG - 2024-10-22 08:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:38 --> Total execution time: 0.0212
DEBUG - 2024-10-22 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:45 --> Total execution time: 0.0277
DEBUG - 2024-10-22 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:55:51 --> Total execution time: 0.0298
DEBUG - 2024-10-22 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:56:07 --> No URI present. Default controller set.
DEBUG - 2024-10-22 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:56:07 --> Total execution time: 0.0217
DEBUG - 2024-10-22 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:56:09 --> Total execution time: 0.0273
DEBUG - 2024-10-22 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 08:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 08:56:12 --> Total execution time: 0.0278
DEBUG - 2024-10-22 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:31 --> No URI present. Default controller set.
DEBUG - 2024-10-22 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:31 --> Total execution time: 0.0223
DEBUG - 2024-10-22 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:36 --> Total execution time: 0.0270
DEBUG - 2024-10-22 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:47 --> Total execution time: 0.0304
DEBUG - 2024-10-22 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:47 --> Total execution time: 0.0250
DEBUG - 2024-10-22 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:01:59 --> Total execution time: 0.0290
DEBUG - 2024-10-22 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:08 --> Total execution time: 0.0262
DEBUG - 2024-10-22 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:14 --> Total execution time: 0.0282
DEBUG - 2024-10-22 09:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:20 --> Total execution time: 0.0264
DEBUG - 2024-10-22 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:22 --> No URI present. Default controller set.
DEBUG - 2024-10-22 09:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:22 --> Total execution time: 0.0239
DEBUG - 2024-10-22 09:02:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:24 --> Total execution time: 0.0272
DEBUG - 2024-10-22 09:02:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:26 --> Total execution time: 0.0223
DEBUG - 2024-10-22 09:02:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:02:48 --> Total execution time: 0.0246
DEBUG - 2024-10-22 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:30:33 --> No URI present. Default controller set.
DEBUG - 2024-10-22 09:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:30:33 --> Total execution time: 0.0271
DEBUG - 2024-10-22 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:30:35 --> Total execution time: 0.0281
DEBUG - 2024-10-22 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:30:38 --> Total execution time: 0.0308
DEBUG - 2024-10-22 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 09:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 09:30:40 --> Total execution time: 0.0216
DEBUG - 2024-10-22 10:54:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 10:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 10:54:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 10:54:15 --> No URI present. Default controller set.
DEBUG - 2024-10-22 10:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 10:54:15 --> Total execution time: 0.0212
DEBUG - 2024-10-22 13:52:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:52:08 --> No URI present. Default controller set.
DEBUG - 2024-10-22 13:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:52:08 --> Total execution time: 0.0258
DEBUG - 2024-10-22 13:52:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:52:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:52:13 --> Total execution time: 0.0286
DEBUG - 2024-10-22 13:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:52:16 --> Total execution time: 0.0246
DEBUG - 2024-10-22 13:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 13:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 13:54:14 --> Total execution time: 0.0243
DEBUG - 2024-10-22 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:56:38 --> No URI present. Default controller set.
DEBUG - 2024-10-22 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:56:38 --> Total execution time: 0.0275
DEBUG - 2024-10-22 14:56:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:56:45 --> Total execution time: 0.0277
DEBUG - 2024-10-22 14:56:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:56:47 --> Total execution time: 0.0243
DEBUG - 2024-10-22 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:57:43 --> Total execution time: 0.0263
DEBUG - 2024-10-22 14:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:58:25 --> Total execution time: 0.0240
DEBUG - 2024-10-22 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:43 --> No URI present. Default controller set.
DEBUG - 2024-10-22 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:58:43 --> Total execution time: 0.0262
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:58:57 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:46 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:47 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 14:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 14:59:49 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:00:36 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:28 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:01:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:01:30 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:14 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:14 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:14 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:15 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:15 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:15 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:16 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:16 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:17 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 15:02:19 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 15:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-22 15:02:19 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-22 17:08:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:08:25 --> No URI present. Default controller set.
DEBUG - 2024-10-22 17:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:08:25 --> Total execution time: 0.0261
DEBUG - 2024-10-22 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:08:31 --> Total execution time: 0.0340
DEBUG - 2024-10-22 17:08:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:08:33 --> Total execution time: 0.0307
DEBUG - 2024-10-22 17:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:24:30 --> No URI present. Default controller set.
DEBUG - 2024-10-22 17:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:24:30 --> Total execution time: 0.0266
DEBUG - 2024-10-22 17:24:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:24:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:24:41 --> Total execution time: 0.0274
DEBUG - 2024-10-22 17:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:24:44 --> Total execution time: 0.0269
DEBUG - 2024-10-22 17:36:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:36:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:36:43 --> Total execution time: 0.0312
DEBUG - 2024-10-22 17:38:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:38:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:38:08 --> Total execution time: 0.0319
DEBUG - 2024-10-22 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:38:11 --> Total execution time: 0.0278
DEBUG - 2024-10-22 17:38:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:38:12 --> Total execution time: 0.0270
DEBUG - 2024-10-22 17:57:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:39 --> No URI present. Default controller set.
DEBUG - 2024-10-22 17:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:39 --> Total execution time: 0.0269
DEBUG - 2024-10-22 17:57:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:44 --> Total execution time: 0.0276
DEBUG - 2024-10-22 17:57:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:48 --> Total execution time: 0.0295
DEBUG - 2024-10-22 17:57:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 17:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 17:57:56 --> Total execution time: 0.0278
DEBUG - 2024-10-22 21:30:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 21:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 21:30:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-22 21:30:30 --> No URI present. Default controller set.
DEBUG - 2024-10-22 21:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-22 21:30:30 --> Total execution time: 0.0217
