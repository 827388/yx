<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-23 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 01:17:02 --> No URI present. Default controller set.
DEBUG - 2024-10-23 01:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 01:17:02 --> Total execution time: 0.1483
DEBUG - 2024-10-23 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 08:01:55 --> No URI present. Default controller set.
DEBUG - 2024-10-23 08:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 08:01:55 --> Total execution time: 0.0900
DEBUG - 2024-10-23 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:40:51 --> No URI present. Default controller set.
DEBUG - 2024-10-23 09:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:40:51 --> Total execution time: 0.0356
DEBUG - 2024-10-23 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:40:54 --> Total execution time: 0.0513
DEBUG - 2024-10-23 09:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:40:57 --> Total execution time: 0.0328
DEBUG - 2024-10-23 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:21 --> Total execution time: 0.0334
DEBUG - 2024-10-23 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:24 --> Total execution time: 0.0376
DEBUG - 2024-10-23 09:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:34 --> Total execution time: 0.0293
DEBUG - 2024-10-23 09:41:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:41:38 --> Total execution time: 0.0262
DEBUG - 2024-10-23 09:42:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:42:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:42:06 --> No URI present. Default controller set.
DEBUG - 2024-10-23 09:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:42:06 --> Total execution time: 0.0304
DEBUG - 2024-10-23 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:42:11 --> Total execution time: 0.0332
DEBUG - 2024-10-23 09:42:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:42:13 --> Total execution time: 0.0300
DEBUG - 2024-10-23 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:08 --> Total execution time: 0.0238
DEBUG - 2024-10-23 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:23 --> Total execution time: 0.0254
DEBUG - 2024-10-23 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:23 --> Total execution time: 0.0245
DEBUG - 2024-10-23 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:24 --> Total execution time: 0.0259
DEBUG - 2024-10-23 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:25 --> Total execution time: 0.0248
DEBUG - 2024-10-23 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:26 --> Total execution time: 0.0233
DEBUG - 2024-10-23 09:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:32 --> No URI present. Default controller set.
DEBUG - 2024-10-23 09:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:32 --> Total execution time: 0.0217
DEBUG - 2024-10-23 09:44:36 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:37 --> Total execution time: 0.0315
DEBUG - 2024-10-23 09:44:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:38 --> Total execution time: 0.0335
DEBUG - 2024-10-23 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:49 --> No URI present. Default controller set.
DEBUG - 2024-10-23 09:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:49 --> Total execution time: 0.0242
DEBUG - 2024-10-23 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:54 --> Total execution time: 0.0261
DEBUG - 2024-10-23 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:55 --> Total execution time: 0.0283
DEBUG - 2024-10-23 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 09:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 09:44:58 --> Total execution time: 0.0236
DEBUG - 2024-10-23 15:36:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 15:36:22 --> No URI present. Default controller set.
DEBUG - 2024-10-23 15:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 15:36:22 --> Total execution time: 0.0508
