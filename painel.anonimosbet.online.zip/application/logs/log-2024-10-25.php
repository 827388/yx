<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-25 15:49:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 15:49:11 --> No URI present. Default controller set.
DEBUG - 2024-10-25 15:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 15:49:11 --> Total execution time: 0.0708
DEBUG - 2024-10-25 18:07:30 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:07:30 --> No URI present. Default controller set.
DEBUG - 2024-10-25 18:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:07:30 --> Total execution time: 0.0347
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:08:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:10 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:11 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:11 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:11 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:11 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:11 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:09:12 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:10:08 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:11:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:26 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:11:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:26 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:11:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:11:27 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:14:48 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:15:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:15:58 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
DEBUG - 2024-10-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-25 18:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-25 18:16:00 --> 404 Page Not Found: Painelroyalapishop/public
