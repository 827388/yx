<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-26 20:15:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-26 20:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-26 20:15:51 --> 404 Page Not Found: Env/index
