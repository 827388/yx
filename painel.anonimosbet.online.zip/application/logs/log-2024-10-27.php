<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-27 06:30:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 06:30:54 --> No URI present. Default controller set.
DEBUG - 2024-10-27 06:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 06:30:54 --> Total execution time: 0.1343
DEBUG - 2024-10-27 13:49:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 13:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 13:49:38 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 13:49:38 --> No URI present. Default controller set.
DEBUG - 2024-10-27 13:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 13:49:38 --> Total execution time: 0.0246
DEBUG - 2024-10-27 13:49:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 13:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 13:49:39 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-27 13:49:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 13:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 13:49:39 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-27 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 15:39:17 --> No URI present. Default controller set.
DEBUG - 2024-10-27 15:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 15:39:17 --> Total execution time: 0.0248
DEBUG - 2024-10-27 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 22:29:34 --> No URI present. Default controller set.
DEBUG - 2024-10-27 22:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 22:29:34 --> Total execution time: 0.0470
DEBUG - 2024-10-27 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:15 --> No URI present. Default controller set.
DEBUG - 2024-10-27 23:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-27 23:34:15 --> Total execution time: 0.0244
DEBUG - 2024-10-27 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:15 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2024-10-27 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:15 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2024-10-27 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:15 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-27 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-27 23:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-27 23:34:16 --> 404 Page Not Found: Faviconico/index
