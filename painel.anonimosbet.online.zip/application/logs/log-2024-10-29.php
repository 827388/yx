<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-29 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-29 14:22:43 --> No URI present. Default controller set.
DEBUG - 2024-10-29 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 14:22:43 --> Total execution time: 0.0847
DEBUG - 2024-10-29 14:52:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-29 14:52:59 --> No URI present. Default controller set.
DEBUG - 2024-10-29 14:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 14:52:59 --> Total execution time: 0.0344
