<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-10-31 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 16:56:52 --> No URI present. Default controller set.
DEBUG - 2024-10-31 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 16:56:52 --> Total execution time: 0.0444
DEBUG - 2024-10-31 18:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:41 --> Total execution time: 0.0373
DEBUG - 2024-10-31 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-31 18:00:42 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2024-10-31 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-31 18:00:42 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2024-10-31 18:00:46 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:46 --> Total execution time: 0.0311
DEBUG - 2024-10-31 18:00:49 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:49 --> Total execution time: 0.0296
DEBUG - 2024-10-31 18:00:53 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:53 --> Total execution time: 0.0262
DEBUG - 2024-10-31 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:00:57 --> Total execution time: 0.0273
DEBUG - 2024-10-31 18:01:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:02 --> Total execution time: 0.0307
DEBUG - 2024-10-31 18:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:03 --> Total execution time: 0.0299
DEBUG - 2024-10-31 18:01:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:04 --> Total execution time: 0.0330
DEBUG - 2024-10-31 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:05 --> Total execution time: 0.0314
DEBUG - 2024-10-31 18:01:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:07 --> Total execution time: 0.0257
DEBUG - 2024-10-31 18:01:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:07 --> Total execution time: 0.0274
DEBUG - 2024-10-31 18:01:09 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:09 --> Total execution time: 0.0265
DEBUG - 2024-10-31 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:10 --> Total execution time: 0.0325
DEBUG - 2024-10-31 18:01:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:13 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:13 --> Total execution time: 0.0206
DEBUG - 2024-10-31 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:18 --> Total execution time: 0.0294
DEBUG - 2024-10-31 18:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:01:41 --> Total execution time: 0.0308
DEBUG - 2024-10-31 18:02:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:08 --> Total execution time: 0.0257
DEBUG - 2024-10-31 18:02:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:12 --> Total execution time: 0.0256
DEBUG - 2024-10-31 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:20 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:20 --> Total execution time: 0.0263
DEBUG - 2024-10-31 18:02:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:29 --> Total execution time: 0.0276
DEBUG - 2024-10-31 18:02:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:31 --> Total execution time: 0.0265
DEBUG - 2024-10-31 18:02:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:34 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:34 --> Total execution time: 0.0232
DEBUG - 2024-10-31 18:02:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:37 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:37 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:37 --> Total execution time: 0.0236
DEBUG - 2024-10-31 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:43 --> Total execution time: 0.0266
DEBUG - 2024-10-31 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:44 --> Total execution time: 0.0214
DEBUG - 2024-10-31 18:02:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:02:54 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:02:54 --> Total execution time: 0.0207
DEBUG - 2024-10-31 18:03:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:03:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:03:08 --> Total execution time: 0.0307
DEBUG - 2024-10-31 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:03:10 --> Total execution time: 0.0248
DEBUG - 2024-10-31 18:03:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:03:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:03:33 --> Total execution time: 0.0261
DEBUG - 2024-10-31 18:04:48 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:04:48 --> Total execution time: 0.0279
DEBUG - 2024-10-31 18:04:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:04:50 --> Total execution time: 0.0284
DEBUG - 2024-10-31 18:04:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:04:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:04:54 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:04:54 --> Total execution time: 0.0234
DEBUG - 2024-10-31 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:01 --> Total execution time: 0.0307
DEBUG - 2024-10-31 18:05:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:02 --> Total execution time: 0.0498
DEBUG - 2024-10-31 18:05:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:11 --> Total execution time: 0.0272
DEBUG - 2024-10-31 18:05:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:16 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:16 --> Total execution time: 0.0270
DEBUG - 2024-10-31 18:05:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:18 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:18 --> Total execution time: 0.0254
DEBUG - 2024-10-31 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:20 --> Total execution time: 0.0269
DEBUG - 2024-10-31 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:22 --> No URI present. Default controller set.
DEBUG - 2024-10-31 18:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:22 --> Total execution time: 0.0222
DEBUG - 2024-10-31 18:05:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:31 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 18:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 18:05:31 --> Total execution time: 0.0268
DEBUG - 2024-10-31 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:00:28 --> No URI present. Default controller set.
DEBUG - 2024-10-31 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:00:28 --> Total execution time: 0.0253
DEBUG - 2024-10-31 20:17:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:32 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:32 --> Total execution time: 0.0241
DEBUG - 2024-10-31 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:39 --> Total execution time: 0.0244
DEBUG - 2024-10-31 20:17:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:51 --> Total execution time: 0.0241
DEBUG - 2024-10-31 20:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:56 --> Total execution time: 0.0289
DEBUG - 2024-10-31 20:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:17:59 --> Total execution time: 0.0247
DEBUG - 2024-10-31 20:18:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:01 --> Total execution time: 0.0380
DEBUG - 2024-10-31 20:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:11 --> No URI present. Default controller set.
DEBUG - 2024-10-31 20:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:11 --> Total execution time: 0.0234
DEBUG - 2024-10-31 20:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:13 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:13 --> Total execution time: 0.0267
DEBUG - 2024-10-31 20:18:17 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:18:17 --> Total execution time: 0.0270
DEBUG - 2024-10-31 20:19:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:19:01 --> UTF-8 Support Enabled
DEBUG - 2024-10-31 20:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-31 20:19:01 --> Total execution time: 0.0321
