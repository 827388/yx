<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-01 22:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-01 22:42:43 --> No URI present. Default controller set.
DEBUG - 2024-11-01 22:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-01 22:42:44 --> Total execution time: 0.0950
