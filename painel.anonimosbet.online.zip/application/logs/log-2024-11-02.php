<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-02 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-02 10:56:42 --> No URI present. Default controller set.
DEBUG - 2024-11-02 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-02 10:56:42 --> Total execution time: 0.0471
DEBUG - 2024-11-02 15:46:37 --> UTF-8 Support Enabled
DEBUG - 2024-11-02 15:46:37 --> No URI present. Default controller set.
DEBUG - 2024-11-02 15:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-02 15:46:37 --> Total execution time: 0.0344
