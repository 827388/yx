<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-03 12:42:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 12:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 12:42:37 --> No URI present. Default controller set.
DEBUG - 2024-11-03 12:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 12:42:37 --> Total execution time: 0.0268
