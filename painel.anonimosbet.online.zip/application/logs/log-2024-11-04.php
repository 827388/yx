<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-04 00:46:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 00:46:55 --> No URI present. Default controller set.
DEBUG - 2024-11-04 00:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 00:46:55 --> Total execution time: 0.0486
DEBUG - 2024-11-04 16:05:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:05:54 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:05:55 --> Total execution time: 0.0701
DEBUG - 2024-11-04 16:05:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:05:57 --> Total execution time: 0.0349
DEBUG - 2024-11-04 16:05:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:05:59 --> Total execution time: 0.0280
DEBUG - 2024-11-04 16:06:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:20 --> Total execution time: 0.0231
DEBUG - 2024-11-04 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:26 --> Total execution time: 0.0257
DEBUG - 2024-11-04 16:06:37 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:37 --> Total execution time: 0.0244
DEBUG - 2024-11-04 16:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:49 --> Total execution time: 0.0245
DEBUG - 2024-11-04 16:06:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:52 --> Total execution time: 0.0243
DEBUG - 2024-11-04 16:06:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:55 --> Total execution time: 0.0244
DEBUG - 2024-11-04 16:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:06:59 --> Total execution time: 0.0246
DEBUG - 2024-11-04 16:07:02 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:02 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:02 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:02 --> Total execution time: 0.0655
DEBUG - 2024-11-04 16:07:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:06 --> Total execution time: 0.0224
DEBUG - 2024-11-04 16:07:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:13 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:13 --> Total execution time: 0.0230
DEBUG - 2024-11-04 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:17 --> Total execution time: 0.0227
DEBUG - 2024-11-04 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:21 --> Total execution time: 0.0307
DEBUG - 2024-11-04 16:07:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:23 --> Total execution time: 0.0251
DEBUG - 2024-11-04 16:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:25 --> Total execution time: 0.0262
DEBUG - 2024-11-04 16:07:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:07:57 --> Total execution time: 0.0252
DEBUG - 2024-11-04 16:44:02 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:44:02 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:44:02 --> Total execution time: 0.0401
DEBUG - 2024-11-04 16:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:44:18 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:44:18 --> Total execution time: 0.0245
DEBUG - 2024-11-04 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 16:49:41 --> No URI present. Default controller set.
DEBUG - 2024-11-04 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 16:49:41 --> Total execution time: 0.0269
DEBUG - 2024-11-04 20:31:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 20:31:56 --> No URI present. Default controller set.
DEBUG - 2024-11-04 20:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 20:31:56 --> Total execution time: 0.0245
DEBUG - 2024-11-04 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 20:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 20:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 20:33:10 --> Total execution time: 0.0272
DEBUG - 2024-11-04 20:33:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 20:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 20:33:13 --> Total execution time: 0.0253
