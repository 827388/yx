<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-05 20:01:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:21 --> No URI present. Default controller set.
DEBUG - 2024-11-05 20:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:21 --> Total execution time: 0.0444
DEBUG - 2024-11-05 20:01:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:39 --> Total execution time: 0.0381
DEBUG - 2024-11-05 20:01:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:42 --> Total execution time: 0.0304
DEBUG - 2024-11-05 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:44 --> Total execution time: 0.0283
DEBUG - 2024-11-05 20:01:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:01:50 --> Total execution time: 0.0237
DEBUG - 2024-11-05 20:02:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:02:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:02:04 --> No URI present. Default controller set.
DEBUG - 2024-11-05 20:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:02:04 --> Total execution time: 0.0273
DEBUG - 2024-11-05 20:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:02:06 --> Total execution time: 0.0246
DEBUG - 2024-11-05 20:02:09 --> UTF-8 Support Enabled
DEBUG - 2024-11-05 20:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-05 20:02:09 --> Total execution time: 0.0252
