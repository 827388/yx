<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-27 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:16 --> No URI present. Default controller set.
DEBUG - 2024-11-27 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:16 --> Total execution time: 0.0329
DEBUG - 2024-11-27 18:07:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:31 --> Total execution time: 0.0292
DEBUG - 2024-11-27 18:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:34 --> Total execution time: 0.0271
DEBUG - 2024-11-27 18:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:46 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:07:46 --> Total execution time: 0.0262
DEBUG - 2024-11-27 18:11:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:11:32 --> Total execution time: 0.0272
DEBUG - 2024-11-27 18:43:24 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:43:24 --> No URI present. Default controller set.
DEBUG - 2024-11-27 18:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:43:24 --> Total execution time: 0.0217
DEBUG - 2024-11-27 18:52:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:52:30 --> No URI present. Default controller set.
DEBUG - 2024-11-27 18:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:52:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 18:52:30 --> No URI present. Default controller set.
DEBUG - 2024-11-27 18:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 18:52:30 --> Total execution time: 0.0241
DEBUG - 2024-11-27 18:52:30 --> Total execution time: 0.0280
DEBUG - 2024-11-27 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 19:07:07 --> No URI present. Default controller set.
DEBUG - 2024-11-27 19:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 19:07:07 --> Total execution time: 0.0214
DEBUG - 2024-11-27 19:07:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 19:07:08 --> No URI present. Default controller set.
DEBUG - 2024-11-27 19:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 19:07:08 --> Total execution time: 0.0200
DEBUG - 2024-11-27 20:00:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 20:00:45 --> No URI present. Default controller set.
DEBUG - 2024-11-27 20:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 20:00:45 --> Total execution time: 0.0211
DEBUG - 2024-11-27 20:05:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 20:05:48 --> No URI present. Default controller set.
DEBUG - 2024-11-27 20:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 20:05:48 --> Total execution time: 0.0255
DEBUG - 2024-11-27 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 20:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-27 20:05:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-27 21:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 21:07:45 --> No URI present. Default controller set.
DEBUG - 2024-11-27 21:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 21:07:45 --> Total execution time: 0.0222
DEBUG - 2024-11-27 21:07:46 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 21:07:46 --> No URI present. Default controller set.
DEBUG - 2024-11-27 21:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 21:07:46 --> Total execution time: 0.0232
DEBUG - 2024-11-27 21:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 21:19:06 --> No URI present. Default controller set.
DEBUG - 2024-11-27 21:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 21:19:06 --> Total execution time: 0.0229
DEBUG - 2024-11-27 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 23:09:31 --> No URI present. Default controller set.
DEBUG - 2024-11-27 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 23:09:31 --> Total execution time: 0.0203
