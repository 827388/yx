<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-28 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 00:37:04 --> No URI present. Default controller set.
DEBUG - 2024-11-28 00:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 00:37:04 --> Total execution time: 0.1117
DEBUG - 2024-11-28 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 00:37:05 --> No URI present. Default controller set.
DEBUG - 2024-11-28 00:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 00:37:05 --> Total execution time: 0.0527
DEBUG - 2024-11-28 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 06:05:49 --> No URI present. Default controller set.
DEBUG - 2024-11-28 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 06:05:49 --> Total execution time: 0.0692
DEBUG - 2024-11-28 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 06:05:50 --> No URI present. Default controller set.
DEBUG - 2024-11-28 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 06:05:50 --> Total execution time: 0.0504
DEBUG - 2024-11-28 06:14:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 06:14:44 --> No URI present. Default controller set.
DEBUG - 2024-11-28 06:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 06:14:44 --> Total execution time: 0.0216
DEBUG - 2024-11-28 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 06:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 06:14:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 09:48:21 --> No URI present. Default controller set.
DEBUG - 2024-11-28 09:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 09:48:21 --> Total execution time: 0.0578
DEBUG - 2024-11-28 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 10:01:40 --> No URI present. Default controller set.
DEBUG - 2024-11-28 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 10:01:40 --> Total execution time: 0.0545
DEBUG - 2024-11-28 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 10:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 10:01:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 10:42:53 --> No URI present. Default controller set.
DEBUG - 2024-11-28 10:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 10:42:53 --> Total execution time: 0.0236
DEBUG - 2024-11-28 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 10:42:55 --> No URI present. Default controller set.
DEBUG - 2024-11-28 10:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 10:42:55 --> Total execution time: 0.0219
DEBUG - 2024-11-28 11:12:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 11:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 11:12:11 --> 404 Page Not Found: Wp-admin/setup-config.php
DEBUG - 2024-11-28 11:12:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 11:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 11:12:12 --> 404 Page Not Found: Wordpress/wp-admin
DEBUG - 2024-11-28 14:07:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 14:07:12 --> No URI present. Default controller set.
DEBUG - 2024-11-28 14:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 14:07:12 --> Total execution time: 0.0825
DEBUG - 2024-11-28 14:07:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 14:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 14:07:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 14:23:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 14:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 14:23:40 --> 404 Page Not Found: Env/index
DEBUG - 2024-11-28 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 15:52:40 --> No URI present. Default controller set.
DEBUG - 2024-11-28 15:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 15:52:40 --> Total execution time: 0.0357
DEBUG - 2024-11-28 15:52:46 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 15:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 15:52:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:18:44 --> No URI present. Default controller set.
DEBUG - 2024-11-28 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 17:18:44 --> Total execution time: 0.0519
DEBUG - 2024-11-28 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:18:52 --> No URI present. Default controller set.
DEBUG - 2024-11-28 17:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:18:52 --> No URI present. Default controller set.
DEBUG - 2024-11-28 17:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 17:18:53 --> Total execution time: 0.0592
DEBUG - 2024-11-28 17:18:53 --> Total execution time: 0.0643
DEBUG - 2024-11-28 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:18:55 --> 404 Page Not Found: Tempphp/index
DEBUG - 2024-11-28 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:18:55 --> 404 Page Not Found: Tempphp/index
DEBUG - 2024-11-28 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:12 --> No URI present. Default controller set.
DEBUG - 2024-11-28 17:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 17:19:12 --> Total execution time: 0.0680
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:19:14 --> 404 Page Not Found: Tempphp/index
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 17:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 17:22:29 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-28 18:08:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:25 --> 404 Page Not Found: _vti_pvt/authors.pwd
DEBUG - 2024-11-28 18:08:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:25 --> 404 Page Not Found: Backupzip/index
DEBUG - 2024-11-28 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:26 --> 404 Page Not Found: Docker-composeyml/index
DEBUG - 2024-11-28 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:26 --> 404 Page Not Found: _vti_pvt/administrators.pwd
DEBUG - 2024-11-28 18:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:26 --> 404 Page Not Found: Api/.env
DEBUG - 2024-11-28 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:26 --> 404 Page Not Found: Backuptargz/index
DEBUG - 2024-11-28 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:26 --> 404 Page Not Found: User_secretsyml/index
DEBUG - 2024-11-28 18:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:27 --> 404 Page Not Found: Feed/index
DEBUG - 2024-11-28 18:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:27 --> 404 Page Not Found: Config/production.json
DEBUG - 2024-11-28 18:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:27 --> 404 Page Not Found: Dumpsql/index
DEBUG - 2024-11-28 18:08:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:28 --> 404 Page Not Found: Configyml/index
DEBUG - 2024-11-28 18:08:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:28 --> 404 Page Not Found: Configxml/index
DEBUG - 2024-11-28 18:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:29 --> 404 Page Not Found: Wp-admin/setup-config.php
DEBUG - 2024-11-28 18:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:29 --> 404 Page Not Found: Ssh/id_ed25519
DEBUG - 2024-11-28 18:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:29 --> 404 Page Not Found: Configyaml/index
DEBUG - 2024-11-28 18:08:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:30 --> 404 Page Not Found: Configjson/index
DEBUG - 2024-11-28 18:08:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:30 --> 404 Page Not Found: Databasesql/index
DEBUG - 2024-11-28 18:08:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:31 --> 404 Page Not Found: Etc/shadow
DEBUG - 2024-11-28 18:08:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:32 --> 404 Page Not Found: _vti_pvt/service.pwd
DEBUG - 2024-11-28 18:08:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:32 --> 404 Page Not Found: Etc/ssl
DEBUG - 2024-11-28 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:33 --> 404 Page Not Found: Aws/credentials
DEBUG - 2024-11-28 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:33 --> 404 Page Not Found: Webconfig/index
DEBUG - 2024-11-28 18:08:34 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:34 --> 404 Page Not Found: Ssh/id_ecdsa
DEBUG - 2024-11-28 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:36 --> 404 Page Not Found: Configphp/index
DEBUG - 2024-11-28 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:36 --> 404 Page Not Found: Cloud-configyml/index
DEBUG - 2024-11-28 18:08:37 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:37 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 18:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:37 --> 404 Page Not Found: Secretsjson/index
ERROR - 2024-11-28 18:08:37 --> 404 Page Not Found: Vscode/sftp.json
DEBUG - 2024-11-28 18:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:08:38 --> 404 Page Not Found: Kube/config
DEBUG - 2024-11-28 18:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:09:09 --> No URI present. Default controller set.
DEBUG - 2024-11-28 18:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 18:09:09 --> Total execution time: 0.0324
DEBUG - 2024-11-28 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:09:10 --> No URI present. Default controller set.
DEBUG - 2024-11-28 18:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 18:09:10 --> Total execution time: 0.0300
DEBUG - 2024-11-28 18:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:31:16 --> No URI present. Default controller set.
DEBUG - 2024-11-28 18:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 18:31:16 --> Total execution time: 0.0225
DEBUG - 2024-11-28 18:31:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 18:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 18:31:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 19:13:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 19:13:11 --> 404 Page Not Found: Env/index
DEBUG - 2024-11-28 19:14:26 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:26 --> No URI present. Default controller set.
DEBUG - 2024-11-28 19:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:26 --> Total execution time: 0.0188
DEBUG - 2024-11-28 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:32 --> Total execution time: 0.0307
DEBUG - 2024-11-28 19:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:39 --> Total execution time: 0.0199
DEBUG - 2024-11-28 19:14:42 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:42 --> Total execution time: 0.0228
DEBUG - 2024-11-28 19:14:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 19:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 19:14:44 --> Total execution time: 0.0243
DEBUG - 2024-11-28 21:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 21:31:30 --> No URI present. Default controller set.
DEBUG - 2024-11-28 21:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 21:31:30 --> Total execution time: 0.0186
DEBUG - 2024-11-28 21:31:35 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 21:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 21:31:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-28 23:07:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 23:07:07 --> No URI present. Default controller set.
DEBUG - 2024-11-28 23:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-28 23:07:07 --> Total execution time: 0.0258
DEBUG - 2024-11-28 23:07:13 --> UTF-8 Support Enabled
DEBUG - 2024-11-28 23:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-28 23:07:13 --> 404 Page Not Found: Faviconico/index
