<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-11-29 02:59:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 02:59:57 --> No URI present. Default controller set.
DEBUG - 2024-11-29 02:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 02:59:57 --> Total execution time: 0.0389
DEBUG - 2024-11-29 03:00:10 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 03:00:10 --> No URI present. Default controller set.
DEBUG - 2024-11-29 03:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 03:00:10 --> Total execution time: 0.0196
DEBUG - 2024-11-29 03:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 03:00:21 --> No URI present. Default controller set.
DEBUG - 2024-11-29 03:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 03:00:21 --> Total execution time: 0.0226
DEBUG - 2024-11-29 03:00:32 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 03:00:32 --> No URI present. Default controller set.
DEBUG - 2024-11-29 03:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 03:00:32 --> Total execution time: 0.0236
DEBUG - 2024-11-29 03:00:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 03:00:55 --> No URI present. Default controller set.
DEBUG - 2024-11-29 03:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 03:00:55 --> Total execution time: 0.0209
DEBUG - 2024-11-29 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:16:56 --> No URI present. Default controller set.
DEBUG - 2024-11-29 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 04:16:56 --> Total execution time: 0.0220
DEBUG - 2024-11-29 04:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:38 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:38 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:38 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:38 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:38 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:39 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:39 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:39 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:39 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:17:39 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:21:31 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:23:54 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 04:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 04:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 04:24:59 --> 404 Page Not Found: Painelanonimosbetonline/public
DEBUG - 2024-11-29 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:02:22 --> No URI present. Default controller set.
DEBUG - 2024-11-29 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:02:22 --> Total execution time: 0.1023
DEBUG - 2024-11-29 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:02:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:02:30 --> Total execution time: 0.0770
DEBUG - 2024-11-29 10:02:33 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:02:33 --> Total execution time: 0.0703
DEBUG - 2024-11-29 10:08:19 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:08:20 --> Total execution time: 0.0820
DEBUG - 2024-11-29 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:08:28 --> Total execution time: 0.0717
DEBUG - 2024-11-29 10:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:08:38 --> Total execution time: 0.0254
DEBUG - 2024-11-29 10:17:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:17:11 --> No URI present. Default controller set.
DEBUG - 2024-11-29 10:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:17:11 --> Total execution time: 0.0274
DEBUG - 2024-11-29 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:20:22 --> Total execution time: 0.0295
DEBUG - 2024-11-29 10:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:20:23 --> Total execution time: 0.0244
DEBUG - 2024-11-29 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:49:08 --> No URI present. Default controller set.
DEBUG - 2024-11-29 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 10:49:08 --> Total execution time: 0.0239
DEBUG - 2024-11-29 10:49:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 10:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 10:49:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-29 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 15:49:59 --> No URI present. Default controller set.
DEBUG - 2024-11-29 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 15:49:59 --> Total execution time: 0.0849
DEBUG - 2024-11-29 15:50:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 15:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 15:50:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 15:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 15:50:04 --> Total execution time: 0.0423
DEBUG - 2024-11-29 15:50:06 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 15:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 15:50:06 --> Total execution time: 0.0436
DEBUG - 2024-11-29 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:57:05 --> No URI present. Default controller set.
DEBUG - 2024-11-29 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 16:57:05 --> Total execution time: 0.0247
DEBUG - 2024-11-29 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 16:57:29 --> 404 Page Not Found: Apizip/index
DEBUG - 2024-11-29 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-29 16:57:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2024-11-29 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:58:44 --> No URI present. Default controller set.
DEBUG - 2024-11-29 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 16:58:44 --> Total execution time: 0.0244
DEBUG - 2024-11-29 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-29 16:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-29 16:58:48 --> Total execution time: 0.0213
