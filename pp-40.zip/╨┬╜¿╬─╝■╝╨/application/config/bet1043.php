<?php

include 'config.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to generate a unique roundId
function generateRoundId() {
    return uniqid();
}

// Function to generate a random event type and balance adjustment
function generateEventAndBalance() {
    // Define possible event types and their impact on balance
    $eventTypes = ["020", "4", "6", "8", "10", "20", "40", "60", "80", "100", "150", "200", "250", "300", "350", "400", "450", "500", "750", "1000", "300", "500", "700", "900"];

    // Pick a random event type
    $et = $eventTypes[array_rand($eventTypes)];

    // Return the event type and its impact (negative for balance deduction)
    return ["et" => $et, "impact" => -intval($et)];
}

// Function to get bet amount from JSON request
function getBetAmount() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    if (isset($data['bets'][0]['betAmount'])) {
        return intval($data['bets'][0]['betAmount']);
    }
    return 0; // Default to 0 if betAmount is not set or invalid
}

// Function to generate random stops for losing condition
function generateRandomStopsLose() {
    $losingSets = [
        ["stops" => ["7", "12", "23", "11"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["17", "8", "12", "23"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["9", "0", "28", "7"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["21", "11", "10", "21"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["14", "16", "30", "6"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["2", "9", "22", "21"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["6", "15", "10", "24"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["14", "6", "26", "29"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["22", "1", "12", "22"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["18", "13", "5", "16"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["3", "0", "27", "19"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["11", "4", "29", "6"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
        ["stops" => ["18", "12", "14", "15"], "wa" => "0", "awa" => "0", "wayWins" => null, "C" => ["specialSymbol" => "3", "multiplier" => "1"]],
    ];

    return $losingSets[array_rand($losingSets)];
}

// Function to generate random stops for winning condition
function generateRandomStopsWin() {
    $betAmount = getBetAmount();

    $winningStops = [
        [
            "stops" => ["18", "22", "20", "6"],
            "wa" => strval($betAmount * 0.5),
            "awa" => strval($betAmount * 0.5),
            "wayWins" => [
                [
                    "symbol" => "2",
                    "hitMask" => [
                        ["0", "1", "0", "0"],
                        ["0", "0", "1", "0"],
                        ["0", "1", "0", "1"],
                        ["0", "0", "0", "0"]
                    ],
                    "winAmount" => strval($betAmount * 0.5),
                    "count" => "3",
                    "ways" => "2",
                ]
            ],
            "C" => ["specialSymbol" => "5", "multiplier" => "1"]
        ],
        [
            "stops" => ["24", "1", "8", "19"],
            "wa" => strval($betAmount * 0.4),
            "awa" => strval($betAmount * 0.4),
            "wayWins" => [
                [
                    "symbol" => "7",
                    "hitMask" => [
                        ["1", "0", "0", "0"],
                        ["0", "0", "0", "1"],
                        ["0", "0", "1", "1"],
                        ["0", "0", "0", "0"]
                    ],
                    "winAmount" => strval($betAmount * 0.4),
                    "count" => "3",
                    "ways" => "2",
                ]
            ],
            "C" => ["specialSymbol" => "3", "multiplier" => "1"]
        ],
        [
            "stops" => ["27", "20", "11", "13"],
            "wa" => strval($betAmount * 4),
            "awa" => strval($betAmount * 4),
            "wayWins" => [
                [
                    "symbol" => "3",
                    "hitMask" => [
                        ["0", "0", "1", "0"],
                        ["0", "1", "1", "0"],
                        ["0", "1", "1", "0"],
                        ["0", "1", "0", "0"]
                    ],
                    "winAmount" => strval($betAmount * 4),
                    "count" => "4",
                    "ways" => "4",
                ]
            ],
            "C" => ["specialSymbol" => "6", "multiplier" => "1"]
        ],
        [
            "stops" => ["26", "25", "20", "7"],
            "wa" => strval($betAmount * 2.5),
            "awa" => strval($betAmount * 2.5),
            "wayWins" => [
                [
                    "symbol" => "6",
                    "hitMask" => [
                        ["1", "0", "0", "0"],
                        ["1", "0", "0", "0"],
                        ["1", "0", "0", "0"],
                        ["1", "0", "0", "0"]
                    ],
                    "winAmount" => strval($betAmount * 2.5),
                    "count" => "4",
                    "ways" => "1",
                ]
            ],
            "C" => ["specialSymbol" => "6", "multiplier" => "10"]
        ],
        [
            "stops" => ["14", "18", "22", "7"],
            "wa" => strval($betAmount * 0.6),
            "awa" => strval($betAmount * 0.6),
            "wayWins" => [
                [
                    "symbol" => "8",
                    "hitMask" => [
                        ["1", "1", "0", "0"],
                        ["1", "1", "0", "0"],
                        ["0", "0", "0", "1"],
                        ["0", "0", "0", "0"]
                    ],
                    "winAmount" => strval($betAmount * 0.6),
                    "count" => "3",
                    "ways" => "4",
                ]
            ],
            "C" => ["specialSymbol" => "1", "multiplier" => "1"]
        ]
    ];

    return $winningStops[array_rand($winningStops)];
}

// Function to generate random stops for either winning or losing condition
function generateRandomStops() {
    // Randomly decide whether to use winning or losing stops
    $isWinning = (mt_rand(0, 6) == 0); // 10% chance of winning stops

    if ($isWinning) {
        return generateRandomStopsWin();
    } else {
        return generateRandomStopsLose();
    }
}

// Generate a unique roundId
$roundId = generateRoundId();

// Generate random event and balance impact
$eventData = generateEventAndBalance();

// Generate random stops
$stopsData = generateRandomStops();
$stops = $stopsData['stops']; // Extract stops array from generated data
$wa = $stopsData['wa']; // Extract wa value from generated data
$awa = $stopsData['awa']; // Extract awa value from generated data
$wayWins = $stopsData['wayWins']; // Extract wayWins data from generated data
$CWins = $stopsData['C'] ?? ["specialSymbol" => "default", "multiplier" => "default"]; // Extract C value or set default

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve JSON data from POST request
$jsonRequest = file_get_contents('php://input');

// Decode the JSON request into an associative array
$requestData = json_decode($jsonRequest, true);

// Fetch user_id from sessionUuid (or set default value)
$userId = isset($requestData['sessionUuid']) ? $requestData['sessionUuid'] : 0; // Default to 0 if not provided

// Prepare the SQL statement to fetch balance_withdrawal for the user_id
$sql = "SELECT balance_withdrawal FROM wallets WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);

// Execute the statement
$stmt->execute();

// Bind the result variable for balance_withdrawal
$stmt->bind_result($currentBalance);

// Fetch the result
$stmt->fetch();

// Close the statement
$stmt->close();

// Adjust balance based on event impact, bet amount, and win amount
$betAmount = getBetAmount();
$winAmount = 0; // Initialize winAmount to 0

// Check if wayWins exist and retrieve winAmount if available
if ($wayWins && isset($wayWins[0]['winAmount'])) {
    $winAmount = intval($wayWins[0]['winAmount']);
}

// Debugging: print current balance and event impact
error_log("Current Balance: " . $currentBalance);
error_log("Event Impact: " . $eventData['impact']);

// Calculate the new balance with decimal precision 10,2


$newBalance = round(($currentBalance * 100 - $betAmount + $winAmount) / 100, 2);

// Debugging: print new balance before updating the database
error_log("New Balance: " . $newBalance);

// Prepare the SQL statement for updating balance_withdrawal
$updateSql = "UPDATE wallets SET balance_withdrawal = ? WHERE user_id = ?";
$updateStmt = $conn->prepare($updateSql);
if ($updateStmt === false) {
    error_log("Prepare statement for update failed: " . $conn->error);
    die("Prepare statement for update failed: " . $conn->error);
}

// Bind parameters and execute the statement
$updateStmt->bind_param("di", $newBalance, $userId); // Assuming $newBalance is a double/float and $userId is an integer

// Execute the statement
$updateStmt->execute();

// Check for errors
if ($updateStmt->errno) {
    error_log("Execute failed: " . $updateStmt->error);
    die("Execute failed: " . $updateStmt->error);
}

// Close the statement
$updateStmt->close();

// Close the database connection
$conn->close();

// Determine if stops are from a winning set or a losing set
$isWinningStops = in_array($stops[0], generateRandomStopsWin()['stops']);

// Simulated data for play/bet response
$responseData = [
    "round" => [
        "status" => "completed",
        "jackpotWin" => null,
        "roundId" => $roundId,
        "possibleActions" => [],
        "events" => [
            [
                "et" => $eventData['et'],
                "etn" => "spin",
                "en" => "0",
                "ba" => "0",
                "bc" => "0",
                "wa" => $wa,
                "wc" => "0",
                "awa" => $awa,
                "awc" => "0",
                "c" => [
                    "activeReelSet" => "default",
                    "stops" => $stops,
                    "scatterWins" => null,
                    "wayWins" => $wayWins, // Include wayWins based on generateRandomStops result
                    "bonusFeatureWon" => null,
                    "bonusFeatureCount" => "0",
                    "c" => $CWins, 
                ]
            ]
        ]
    ],
    "promotionNoLongerAvailable" => false,
    "promotionWin" => null,
    "offer" => null,
    "freeRoundOffer" => null,
    "statusCode" => 0,
    "statusMessage" => "",
    "accountBalance" => [
        "currencyCode" => "USD",
        "balance" => $newBalance = intval($newBalance * 100), // Ensure balance is formatted to 2 decimal places
        "realBalance" => null,
        "bonusBalance" => null
    ],
    "statusData" => null,
    "dialog" => null,
    "customData" => null,
    "serverTime" => date("Y-m-d\TH:i:s\Z")
];

// Set headers
header('Content-Type: application/json');

// Send JSON response
echo json_encode($responseData, JSON_PRETTY_PRINT);
?>