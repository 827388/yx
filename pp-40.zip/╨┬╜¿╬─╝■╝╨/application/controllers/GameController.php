<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GameController extends CI_Controller {

    public function spin() {
        // Retrieve the input data
        $action = $this->input->get('action');
        $symbol = $this->input->get('symbol');
        $c = $this->input->get('c');
        $l = $this->input->get('l');
        $bl = $this->input->get('bl');
        $index = $this->input->get('index');
        $counter = $this->input->get('counter');
        $repeat = $this->input->get('repeat');
        $mgckey = $this->input->get('mgckey');

        // Process the spin action
        if ($action == 'doSpin') {
            $result = $this->processSpin($symbol, $c, $l, $bl, $index, $counter, $repeat, $mgckey);
            echo $result;
        } else {
            echo 'error=Invalid action';
        }
    }

    private function processSpin($symbol, $c, $l, $bl, $index, $counter, $repeat, $mgckey) {
        // Simulate the spin result
        $tw = 1.00;
        $tmb = "7,9~11,9~13,9~15,9~17,9~20,9~21,9~26,9";
        $prg_m = "wm";
        $balance = 99998.00;
        $prg = 1;
        $balance_cash = 99998.00;
        $reel_set = 0;
        $balance_bonus = 0.00;
        $na = "s";
        $rs = "t";
        $tmb_win = 1.00;
        $l0 = "0~1.00~7~11~13~15~17~20~21~26";
        $rs_p = 0;
        $bl = 0;
        $stime = time();
        $sa = "4,7,4,5,8,11";
        $sb = "5,8,10,10,6,4";
        $rs_c = 1;
        $sh = 5;
        $rs_m = 1;
        $c = 0.10;
        $sver = 5;
        $counter = 4;
        $ntp = -2.00;
        $l = 20;
        $s = "1,7,4,7,10,11,3,9,7,7,10,9,3,9,7,9,11,9,11,6,9,9,11,10,11,6,9,10,6,10";
        $w = 1.00;

        return "tw=$tw&tmb=$tmb&prg_m=$prg_m&balance=" . number_format($balance, 2) . "&prg=$prg&index=$index&balance_cash=" . number_format($balance_cash, 2) . "&reel_set=$reel_set&balance_bonus=" . number_format($balance_bonus, 2) . "&na=$na&rs=$rs&tmb_win=$tmb_win&l0=$l0&rs_p=$rs_p&bl=$bl&stime=$stime&sa=$sa&sb=$sb&rs_c=$rs_c&sh=$sh&rs_m=$rs_m&c=$c&sver=$sver&counter=$counter&ntp=$ntp&l=$l&s=$s&w=$w";
    }
}